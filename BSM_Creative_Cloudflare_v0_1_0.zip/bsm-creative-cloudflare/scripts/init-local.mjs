import {writeFile,access,chmod} from 'node:fs/promises';
import {randomBytes} from 'node:crypto';
const file=new URL('../.dev.vars',import.meta.url);
try{await access(file);console.log('Existing local credentials preserved.');}
catch{await writeFile(file,`APP_ENV="development"\nDEV_LOGIN_TOKEN="${randomBytes(32).toString('hex')}"\nDEV_SESSION_SECRET="${randomBytes(48).toString('hex')}"\n`,{flag:'wx',mode:0o600});await chmod(file,0o600);console.log('Private local credentials created; no credential printed.');}
