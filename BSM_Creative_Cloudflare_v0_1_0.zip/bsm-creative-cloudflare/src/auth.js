import {createRemoteJWKSet,jwtVerify,SignJWT} from 'jose';
const keys=new Map();
export const isLocal=(request,env)=>env.APP_ENV==='development'&&['127.0.0.1','localhost','[::1]'].includes(new URL(request.url).hostname)&&new URL(request.url).protocol==='http:';
const secret=env=>new TextEncoder().encode(env.DEV_SESSION_SECRET||'');
export async function verifyAccess(token,config,jwks){
 const {payload}=await jwtVerify(token,jwks,{issuer:`https://${config.ACCESS_TEAM_DOMAIN}`,audience:config.ACCESS_AUD,algorithms:['RS256']});
 if(typeof payload.email!=='string'||payload.email.toLowerCase()!==config.OWNER_EMAIL.toLowerCase())throw Error('Wrong owner');
 return {email:payload.email,kind:'cloudflare-access'};
}
export async function authenticate(request,env){
 if(isLocal(request,env)){
  if((env.DEV_SESSION_SECRET||'').length<32)return null;
  const token=request.headers.get('cookie')?.match(/(?:^|;\s*)bcs_session=([^;]+)/)?.[1];
  if(!token)return null;
  try{await jwtVerify(token,secret(env),{issuer:'bcs-local',audience:'bcs-local',algorithms:['HS256']});return {email:'local-owner',kind:'local-test'};}catch{return null;}
 }
 if(!env.ACCESS_AUD||!env.OWNER_EMAIL||!/^[a-z0-9-]+\.cloudflareaccess\.com$/.test(env.ACCESS_TEAM_DOMAIN||''))return null;
 const token=request.headers.get('Cf-Access-Jwt-Assertion');if(!token)return null;
 try{
  if(!keys.has(env.ACCESS_TEAM_DOMAIN))keys.set(env.ACCESS_TEAM_DOMAIN,createRemoteJWKSet(new URL(`https://${env.ACCESS_TEAM_DOMAIN}/cdn-cgi/access/certs`),{timeoutDuration:5000}));
  return await verifyAccess(token,env,keys.get(env.ACCESS_TEAM_DOMAIN));
 }catch{return null;}
}
export async function localLogin(request,env){
 if(!isLocal(request,env)||(env.DEV_LOGIN_TOKEN||'').length<32||(env.DEV_SESSION_SECRET||'').length<32)return new Response('Not available',{status:403});
 let data;try{data=await request.json();}catch{return new Response('Invalid request',{status:400});}
 const hash=async x=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x)));
 const a=await hash(String(data.token||'')),b=await hash(env.DEV_LOGIN_TOKEN);let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];
 if(diff)return new Response('Invalid local credential',{status:401});
 const token=await new SignJWT({sub:'local-owner'}).setProtectedHeader({alg:'HS256'}).setIssuer('bcs-local').setAudience('bcs-local').setIssuedAt().setExpirationTime('8h').sign(secret(env));
 return Response.json({ok:true},{headers:{'Set-Cookie':`bcs_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`}});
}
