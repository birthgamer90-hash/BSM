import {authenticate,isLocal,localLogin} from './auth.js';
import {canonical,sha256,inspectImage,inspectOutput,normalizeIntake,makeItems,PRESET_VERSION,presetFor} from './media.js';
import {zipSync,strToU8} from 'fflate';
const now=()=>new Date().toISOString(),id=()=>crypto.randomUUID();
const json=(data,status=200)=>Response.json(data,{status});
function error(code,status=409){const e=new Error(code);e.status=status;throw e;}
const stmt=(env,sql,...args)=>env.DB.prepare(sql).bind(...args);
const one=(env,sql,...args)=>stmt(env,sql,...args).first();
const all=async(env,sql,...args)=>(await stmt(env,sql,...args).all()).results;
const parse=s=>JSON.parse(s);
async function read(request,limit=32000){const reader=request.body?.getReader();if(!reader)return new Uint8Array();let chunks=[],n=0;while(true){const {done,value}=await reader.read();if(done)break;n+=value.length;if(n>limit){await reader.cancel();error('BODY_TOO_LARGE',413);}chunks.push(value);}const bytes=new Uint8Array(n);let p=0;for(const c of chunks){bytes.set(c,p);p+=c.length;}return bytes;}
async function verifiedObject(env,key,hash){const o=await env.BUCKET.get(key);if(!o)error('OBJECT_MISSING');const bytes=new Uint8Array(await o.arrayBuffer());if(await sha256(bytes)!==hash)error('OBJECT_HASH_MISMATCH');return bytes;}
async function storageQuota(env,size){const stored=await one(env,'SELECT coalesce(sum(size),0) bytes FROM (SELECT size FROM assets UNION ALL SELECT size FROM artifacts)');if(stored.bytes+size>100_000_000)error('STORAGE_APPLICATION_CAP',422);}
async function stage(env,key,bytes,mime,metadata){
 const hash=await sha256(bytes);const existing=await env.BUCKET.head(key);
 if(existing){if(existing.customMetadata?.sha256!==hash)error('IMMUTABLE_OBJECT_CONFLICT');}
 else{const put=await env.BUCKET.put(key,bytes,{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:mime},customMetadata:{...metadata,sha256:hash}});if(!put){const h=await env.BUCKET.head(key);if(h?.customMetadata?.sha256!==hash)error('IMMUTABLE_OBJECT_CONFLICT');}}
 await verifiedObject(env,key,hash);return hash;
}
async function current(env,workId){const w=await one(env,'SELECT * FROM works WHERE id=?',workId);if(!w)error('WORK_NOT_FOUND',404);const r=await one(env,'SELECT * FROM revisions WHERE work_id=? AND revision=?',workId,w.revision);const data=parse(r.data);if(await sha256(canonical(data))!==r.data_hash)error('INTAKE_HASH_MISMATCH');if(data.format_rules&&await sha256(canonical(data.format_rules))!==r.preset_hash)error('PRESET_HASH_MISMATCH');return {...w,data,data_hash:r.data_hash,preset_hash:r.preset_hash};}
async function verifyJournal(env){
 const result=await env.DB.batch([env.DB.prepare('SELECT * FROM control WHERE id=1'),env.DB.prepare('SELECT * FROM events ORDER BY seq')]);let head='GENESIS',seq=0;
 for(const e of result[1].results){if(e.seq!==++seq||e.previous_hash!==head)error('JOURNAL_CHAIN_MISMATCH');const hash=await sha256(canonical({seq:e.seq,previous:e.previous_hash,type:e.type,work:e.work_id,revision:e.revision,data:parse(e.data),created_at:e.created_at}));if(hash!==e.hash)error('JOURNAL_HASH_MISMATCH');head=hash;}
 if(result[0].results[0]?.version!==seq||result[0].results[0]?.head_hash!==head)error('JOURNAL_HEAD_MISMATCH');return {status:'VERIFIED',events:seq,head_hash:head};
}
async function pins(env,ids){const result=[];for(const aid of ids){const a=await one(env,'SELECT * FROM assets WHERE id=?',aid);if(!a||a.status!=='APPROVED')error('APPROVED_SOURCE_REQUIRED');await verifiedObject(env,a.object_key,a.sha256);result.push({asset_id:a.id,revision:a.asset_revision,sha256:a.sha256,name:a.name,category:a.category});}return result;}
async function verifyWorkPins(env,w){const latest=await pins(env,w.data.asset_ids);for(const pin of w.data.input_pins){const a=latest.find(x=>x.asset_id===pin.asset_id);if(!a||a.sha256!==pin.sha256||a.revision!==pin.revision)error('PIN_HASH_CHANGED');}return latest;}
async function releasePins(env,ids){const result=[];for(const wid of ids){const w=await current(env,wid);if(w.state!=='EXPORT_READY'||w.data.module==='publishing')error('APPROVED_RELEASE_REQUIRED');const m=await manifest(env,w);const approval=await one(env,"SELECT * FROM approvals WHERE scope='RELEASE' AND target_id=? AND revision=? AND sha256=?",wid,w.revision,m.manifest_sha256);if(!approval)error('APPROVED_RELEASE_REQUIRED');result.push({work_id:wid,revision:w.revision,manifest_sha256:m.manifest_sha256});}return result;}
async function mutation(request,env,actor,action){
 const command=request.headers.get('Idempotency-Key');if(!command||!/^[A-Za-z0-9_-]{8,100}$/.test(command))error('IDEMPOTENCY_KEY_REQUIRED',400);
 const path=new URL(request.url).pathname,key=actor.email+'|'+path+'|'+command;
 const raw=await read(request,path==='/api/assets'||path.endsWith('/output')?2_000_000:32000);
 const requestHash=await sha256(request.method+'|'+path+'|'+(request.headers.get('X-BCS-Metadata')||'')+'|'+await sha256(raw));
 const old=await one(env,'SELECT * FROM commands WHERE command_key=?',key);
 if(old){if(old.request_hash!==requestHash)error('IDEMPOTENCY_CONFLICT');return json(parse(old.response));}
 const control=await one(env,'SELECT * FROM control WHERE id=1');if(!control)error('DATABASE_NOT_INITIALIZED',503);
 let data={};if(raw.length&&!path.endsWith('/output')&&path!=='/api/assets'){try{data=parse(new TextDecoder().decode(raw));}catch{error('INVALID_JSON',400);}if(!data||Array.isArray(data)||typeof data!=='object')error('INVALID_JSON',400);}
 const result=await action({raw,data,command,actor,control,objectId:(await sha256(key)).slice(0,32)});
 const eventId=id(),eventData=canonical(result.event||{}),time=now(),seq=control.version+1;
 const eventHash=await sha256(canonical({seq,previous:control.head_hash,type:result.type,work:result.work||null,revision:result.revision||null,data:parse(eventData),created_at:time}));
 const guard=id();const statements=[
  stmt(env,'INSERT INTO transaction_guard(id,acquired) VALUES(?,(SELECT 1 FROM control WHERE id=1 AND version=? AND head_hash=?))',guard,control.version,control.head_hash),
  ...(result.sql||[]),
  stmt(env,'INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?)',eventId,seq,result.work||null,result.revision||null,result.type,control.head_hash,eventHash,eventData,time),
  stmt(env,'UPDATE control SET version=?,head_hash=? WHERE id=1',seq,eventHash),
  stmt(env,'INSERT INTO commands VALUES(?,?,?,?)',key,requestHash,canonical(result.response),time),
  stmt(env,'DELETE FROM transaction_guard WHERE id=?',guard)
 ];
 try{await env.DB.batch(statements);}catch(e){const cached=await one(env,'SELECT * FROM commands WHERE command_key=?',key);if(cached?.request_hash===requestHash)return json(parse(cached.response));if(/transaction_guard|acquired|UNIQUE constraint/.test(String(e)))error('STATE_CONFLICT_REFRESH_AND_RETRY');throw e;}
 return json(result.response);
}
function matchRevision(work,data){if(Number(data.revision)!==work.revision)error('REVISION_CONFLICT');}
async function itemFor(env,work,itemId,data){matchRevision(work,data);const item=await one(env,'SELECT * FROM items WHERE work_id=? AND revision=? AND item_id=?',work.id,work.revision,itemId);if(!item)error('ITEM_NOT_FOUND',404);return item;}
function matchAttempt(work,item,data){if(work.state!=='RUNNING'||item.state!=='RUNNING'||item.fence!==Number(data.fence)||item.attempt_id!==data.attempt_id)error('STALE_ATTEMPT');if(item.lease_until<Date.now())error('LEASE_EXPIRED_RECONCILE_FIRST');}
async function workDetail(env,wid){const w=await current(env,wid);return {...w,items:await all(env,'SELECT * FROM items WHERE work_id=? AND revision=? ORDER BY item_id',wid,w.revision),artifacts:(await all(env,'SELECT * FROM artifacts WHERE work_id=? AND revision=? ORDER BY created_at',wid,w.revision)).map(a=>({...a,metadata:parse(a.metadata),technical:parse(a.technical),review:a.review?parse(a.review):null})),checkpoints:await all(env,'SELECT * FROM checkpoints WHERE work_id=? ORDER BY created_at',wid),events:await all(env,'SELECT * FROM events WHERE work_id=? ORDER BY seq',wid),approvals:await all(env,'SELECT * FROM approvals WHERE target_id=? ORDER BY created_at',wid)};}
async function manifest(env,w){
 const items=await all(env,'SELECT * FROM items WHERE work_id=? AND revision=? ORDER BY item_id',w.id,w.revision);const files=[];
 for(const item of items){if(item.state!=='QA_PASSED'||!item.artifact_id)error('QA_GATE_INCOMPLETE');const a=await one(env,'SELECT * FROM artifacts WHERE id=?',item.artifact_id);if(!a||!a.review||a.fence!==item.fence)error('QA_GATE_INCOMPLETE');await verifiedObject(env,a.object_key,a.sha256);files.push({id:a.id,name:a.filename,sha256:a.sha256,size:a.size});}
 await verifyWorkPins(env,w);
 if(w.data.module==='publishing'){
  for(const source of w.data.source_release_pins||[]){
   const r=await one(env,'SELECT * FROM revisions WHERE work_id=? AND revision=?',source.work_id,source.revision);if(!r)error('SOURCE_RELEASE_MISSING');
   const sw={id:source.work_id,revision:source.revision,data:parse(r.data),data_hash:r.data_hash,preset_hash:r.preset_hash};if(sw.data.module==='publishing')error('NESTED_PACKAGE_NOT_SUPPORTED');const sm=await manifest(env,sw);
   const approval=await one(env,"SELECT id FROM approvals WHERE scope='RELEASE' AND target_id=? AND revision=? AND sha256=?",sw.id,sw.revision,source.manifest_sha256);if(!approval||sm.manifest_sha256!==source.manifest_sha256)error('SOURCE_RELEASE_HASH_CHANGED');
   files.push(...sm.files.map(f=>({...f,name:source.work_id+'/'+f.name})));
  }
 }
 const total=files.reduce((n,f)=>n+f.size,0);if(total>20_000_000)error('PACKAGE_RESOURCE_LIMIT',422);
 if(w.data.product_type==='regular_emoji'&&total>=20_000_000)error('FILE_SIZE',422);
 const payload={schema_version:'1.0',work_id:w.id,revision:w.revision,intake_hash:w.data_hash,preset_hash:w.preset_hash,input_pins:w.data.input_pins,files};
 return {...payload,manifest_sha256:await sha256(canonical(payload))};
}
function uploadMetadata(request){try{const h=request.headers.get('X-BCS-Metadata')||'';if(h.length>12000)error('METADATA_TOO_LARGE',400);return parse(decodeURIComponent(h));}catch{error('UPLOAD_METADATA_REQUIRED',400);}}
async function api(request,env,actor){
 const path=new URL(request.url).pathname,method=request.method;
 if(method==='GET'&&path==='/api/me')return json({owner:actor.email,auth:actor.kind,environment:env.APP_ENV,modules:Object.keys((await import('./media.js')).TYPES),capabilities:{storage:'private-r2',state:'d1',work_bridge:'MANUAL_HANDOFF',multi_worker:'BLOCKED_NOT_VERIFIED',theme:'BLOCKED_SPEC_UNVERIFIED',paid_ai:false,publish:false,polling_seconds:5}});
 if(method==='GET'&&path==='/api/dashboard')return json({works:await all(env,'SELECT * FROM works ORDER BY created_at DESC LIMIT 200'),counts:await one(env,"SELECT (SELECT count(*) FROM works) works,(SELECT count(*) FROM assets) assets,(SELECT count(*) FROM assets WHERE status='APPROVED') masters,(SELECT count(*) FROM works WHERE state='EXPORT_READY') ready"),recent:await all(env,'SELECT * FROM events ORDER BY seq DESC LIMIT 15')});
 if(method==='GET'&&path==='/api/assets')return json((await all(env,'SELECT * FROM assets ORDER BY created_at DESC')).map(a=>({...a,metadata:parse(a.metadata),rights:parse(a.rights)})));
 if(method==='POST'&&path==='/api/assets')return mutation(request,env,actor,async c=>{
  const m=uploadMetadata(request);if(!m.name||typeof m.name!=='string'||m.name.length>150||typeof m.rights?.owner!=='string'||typeof m.rights?.license!=='string'||!m.rights.owner.trim()||!m.rights.license.trim()||m.rights.owner.length>500||m.rights.license.length>2000)error('RIGHTS_AND_NAME_REQUIRED',422);
  if(!['CHARACTER_IDENTITY','WARDROBE','EXPRESSION','POSE','PROP','BACKGROUND','STYLE_REFERENCE','COMPOSITION_REFERENCE','TEST_FIXTURE'].includes(m.category))error('INVALID_CATEGORY',422);
  const meta=await inspectImage(c.raw,m.name);let parent=null;if(m.parent_id){parent=await one(env,'SELECT * FROM assets WHERE id=?',m.parent_id);if(!parent||parent.status!=='APPROVED')error('APPROVED_PARENT_REQUIRED');await verifiedObject(env,parent.object_key,parent.sha256);}
  if(m.category==='WARDROBE'&&!parent)error('APPROVED_PARENT_REQUIRED');
  await storageQuota(env,c.raw.length);const aid=c.objectId,key=`assets/${aid}/${await sha256(c.raw)}`,hash=await stage(env,key,c.raw,meta.mime,{asset_id:aid});
  return {type:'ASSET_DRAFT_CREATED',event:{asset_id:aid,sha256:hash},response:{id:aid,sha256:hash,status:'DRAFT'},sql:[stmt(env,'INSERT INTO assets VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',aid,m.name,key,hash,c.raw.length,meta.mime,m.category,canonical(m.rights),parent?.id||null,parent?parent.asset_revision+1:1,'DRAFT',canonical(meta),now(),null)]};
 });
 let match=path.match(/^\/api\/assets\/([a-z0-9-]+)\/approve$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const a=await one(env,'SELECT * FROM assets WHERE id=?',match[1]);if(!a)error('ASSET_NOT_FOUND',404);if(a.status!=='DRAFT')error('MASTER_ALREADY_IMMUTABLE');if(c.data.sha256!==a.sha256||c.data.creative_reviewed!==true||c.data.rights_reviewed!==true)error('MASTER_APPROVAL_REQUIRED');
  if(parse(a.metadata).format==='APNG')error('STATIC_MASTER_REQUIRED');await verifiedObject(env,a.object_key,a.sha256);
  return {type:'MASTER_APPROVED',event:{id:a.id,sha256:a.sha256},response:{id:a.id,status:'APPROVED'},sql:[stmt(env,"UPDATE assets SET status='APPROVED',approved_at=? WHERE id=?",now(),a.id),stmt(env,'INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)',id(),'MASTER',a.id,a.asset_revision,a.sha256,actor.email,canonical(c.data),now())]};
 });
 match=path.match(/^\/api\/(assets|artifacts)\/([a-z0-9-]+)\/file$/);
 if(method==='GET'&&match){const a=await one(env,`SELECT * FROM ${match[1]} WHERE id=?`,match[2]);if(!a)error('FILE_NOT_FOUND',404);const bytes=await verifiedObject(env,a.object_key,a.sha256);return new Response(bytes,{headers:{'Content-Type':a.media,'Content-Disposition':new URL(request.url).searchParams.has('download')?`attachment; filename*=UTF-8''${encodeURIComponent(a.name||a.filename)}`:'inline'}});}
 if(method==='POST'&&path==='/api/works')return mutation(request,env,actor,async c=>{
  const data=normalizeIntake(c.data);data.input_pins=await pins(env,data.asset_ids);data.source_release_pins=await releasePins(env,data.source_work_ids);data.format_rules=presetFor(data);const wid='BCS-'+c.objectId,items=makeItems(data),ph=await sha256(canonical(data.format_rules));
  const sql=[stmt(env,'INSERT INTO works VALUES(?,?,?,?,?)',wid,1,'PLANNED',data.title,now()),stmt(env,'INSERT INTO revisions VALUES(?,?,?,?,?)',wid,1,canonical(data),await sha256(canonical(data)),ph),...items.map(i=>stmt(env,'INSERT INTO items(work_id,revision,item_id,filename,role,state) VALUES(?,?,?,?,?,?)',wid,1,i.id,i.filename,i.role,'PLANNED'))];
  return {type:'WORK_PLANNED',work:wid,revision:1,event:{items:items.length,preset_hash:ph},response:{id:wid,revision:1,state:'PLANNED'},sql};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)$/);
 if(method==='GET'&&match)return json(await workDetail(env,match[1]));
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/revise$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]);matchRevision(w,c.data);const active=await one(env,"SELECT count(*) n FROM items WHERE work_id=? AND revision=? AND (state='RUNNING' OR remote_status='UNKNOWN_REMOTE')",w.id,w.revision);if(active.n)error('RECONCILE_ACTIVE_WORK_FIRST');
  const data=normalizeIntake({...w.data,...c.data.changes});data.input_pins=await pins(env,data.asset_ids);data.source_release_pins=await releasePins(env,data.source_work_ids);data.format_rules=presetFor(data);const rev=w.revision+1,items=makeItems(data),ph=await sha256(canonical(data.format_rules));
  return {type:'WORK_REVISED_APPROVALS_INVALIDATED',work:w.id,revision:rev,event:{previous_revision:w.revision},response:{id:w.id,revision:rev,state:'PLANNED'},sql:[stmt(env,"UPDATE works SET revision=?,state='PLANNED',title=? WHERE id=?",rev,data.title,w.id),stmt(env,'INSERT INTO revisions VALUES(?,?,?,?,?)',w.id,rev,canonical(data),await sha256(canonical(data)),ph),...items.map(i=>stmt(env,'INSERT INTO items(work_id,revision,item_id,filename,role,state) VALUES(?,?,?,?,?,?)',w.id,rev,i.id,i.filename,i.role,'PLANNED'))]};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/(approve-plan|pause|cancel)$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]);matchRevision(w,c.data);const action=match[2];let state,sql=[];
  if(action==='approve-plan'){
   if(w.state!=='PLANNED')error('STATE_CONFLICT');if(w.data.product_type==='theme')error('THEME_SPEC_UNVERIFIED');if(c.data.plan_reviewed!==true)error('PLAN_APPROVAL_REQUIRED');await verifyWorkPins(env,w);state='READY';
   sql.push(stmt(env,"UPDATE items SET state='READY' WHERE work_id=? AND revision=?",w.id,w.revision),stmt(env,'INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)',id(),'PLAN',w.id,w.revision,w.data_hash,actor.email,canonical(c.data),now()));
  }else{if(['EXPORT_READY','CANCELLED'].includes(w.state))error('TERMINAL_STATE');state=action==='pause'?'PAUSED':'CANCELLED';}
  sql.push(stmt(env,'UPDATE works SET state=? WHERE id=?',state,w.id));
  return {type:action.toUpperCase().replace('-','_'),work:w.id,revision:w.revision,event:{state},response:{state},sql};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/handoff$/);
 if(method==='GET'&&match){const w=await current(env,match[1]);const items=await all(env,'SELECT * FROM items WHERE work_id=? AND revision=? ORDER BY item_id',w.id,w.revision);
  const text=`# BSM Creative Studio — Work handoff\n\nWork ID: ${w.id}\nRevision: ${w.revision}\nIntake hash: ${w.data_hash}\nPreset hash: ${w.preset_hash}\n\nThis is a manual handoff, not an API invocation. Do not import old project assets. Do not call paid APIs, publish, or generate Grok videos. Stop at approval gates.\n\n## Intake\n\n${canonical(w.data)}\n\n## Items\n\n${canonical(items)}\n\n## Instructions\n\nUse only approved pinned references; the owner must download/attach private R2 files in Work. Links alone do not prove image bytes were inspected. If any reference is unavailable, BLOCKED. No automated Work authentication is supplied.\n\nOnly execute when the owner authorizes generation and this plan is approved. An exported plan alone does not authorize execution. Return exact files per item, exact-text proof, tool/usage receipts and QA evidence. Before each external action save a checkpoint. Recover by checking latest receipt and actual files before retrying. Unknown remote status must stop, never blindly regenerate.\n\nLINE: validate actual PNG/APNG bytes, roles/counts/dimensions, 5-20 frames, 1-4 plays, integer playback and total <=4s. Animated sticker main is APNG; tab static PNG. Emoji APNG cap 300000 bytes. Theme is BLOCKED until a complete versioned spec is supplied.\n\nUpload each result through the owner portal against its current item/attempt/fence. Visual/rights/text reviews and final release must be approved by the owner. Cloudflare holds state and files; Work is the external execution environment. Multi-worker execution is not enabled.\n`;
  return new Response(text,{headers:{'Content-Type':'text/markdown; charset=utf-8','Content-Disposition':`attachment; filename="${w.id}-r${w.revision}-work.md"`}});
 }
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/items\/([a-z0-9]+)\/(claim|heartbeat|checkpoint|unknown|output)$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]),action=match[3],data=action==='output'?uploadMetadata(request):c.data,item=await itemFor(env,w,match[2],data);let sql=[],response={},event={item_id:item.item_id};
  if(action==='claim'){
   if(!['READY','RUNNING'].includes(w.state)||item.state!=='READY')error('ITEM_NOT_READY');if(w.data.preset_version!==PRESET_VERSION)error('PRESET_CHANGED_CREATE_REVIEWED_REVISION');if(await sha256(canonical(w.data.format_rules))!==w.preset_hash)error('PRESET_HASH_CHANGED');await verifyWorkPins(env,w);
   const active=await one(env,"SELECT count(*) n FROM items WHERE work_id=? AND revision=? AND state='RUNNING'",w.id,w.revision);if(active.n)error('SINGLE_WORKER_ACTIVE_RECONCILE_FIRST');
   const attempt=id(),fence=item.fence+1,leaseUntil=Date.now()+180_000,owner=String(data.worker||'owner-manual').slice(0,100);
   sql.push(stmt(env,"UPDATE items SET state='RUNNING',attempt_id=?,fence=?,lease_owner=?,lease_until=?,remote_status='NOT_DISPATCHED' WHERE work_id=? AND revision=? AND item_id=?",attempt,fence,owner,leaseUntil,w.id,w.revision,item.item_id),stmt(env,"UPDATE works SET state='RUNNING' WHERE id=?",w.id),stmt(env,'INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?)',id(),w.id,w.revision,item.item_id,attempt,fence,'CP_PLAN',canonical({input_pins:w.data.input_pins,preset_hash:w.preset_hash,filename:item.filename}),now()));
   response={attempt_id:attempt,fence,lease_until:leaseUntil,item_id:item.item_id};event={...event,...response};
  }else{
   matchAttempt(w,item,data);
   if(action==='heartbeat'){sql.push(stmt(env,'UPDATE items SET lease_until=? WHERE work_id=? AND revision=? AND item_id=?',Date.now()+180_000,w.id,w.revision,item.item_id));response={renewed:true};}
   if(action==='unknown'){sql.push(stmt(env,"UPDATE items SET remote_status='UNKNOWN_REMOTE' WHERE work_id=? AND revision=? AND item_id=?",w.id,w.revision,item.item_id));response={remote_status:'UNKNOWN_REMOTE'};}
   if(action==='checkpoint'){
    if(!['CP_DISPATCH','CP_RECEIPT','CP_NOTE'].includes(data.kind)||!data.evidence||typeof data.evidence!=='string'||data.evidence.length>6000)error('CHECKPOINT_EVIDENCE_REQUIRED',422);
    const cp=id(),payload=canonical({evidence:data.evidence,source:'OWNER_MANUAL_RECEIPT'});sql.push(stmt(env,'INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?)',cp,w.id,w.revision,item.item_id,item.attempt_id,item.fence,data.kind,payload,now()));if(data.kind==='CP_DISPATCH')sql.push(stmt(env,"UPDATE items SET remote_status='UNKNOWN_REMOTE' WHERE work_id=? AND revision=? AND item_id=?",w.id,w.revision,item.item_id));response={checkpoint_id:cp};event={...event,checkpoint_id:cp,checkpoint_data_hash:await sha256(payload)};
   }
   if(action==='output'){
    if(data.filename!==item.filename)error('FILE_NAMES',422);const meta=await inspectOutput(c.raw,item.filename,w.data,item.role);await storageQuota(env,c.raw.length);const aid=c.objectId,key=`works/${w.id}/r${w.revision}/${item.item_id}/${item.attempt_id}/${aid}/${await sha256(c.raw)}`;
    const hash=await stage(env,key,c.raw,meta.mime,{work_id:w.id,revision:String(w.revision),item_id:item.item_id,attempt_id:item.attempt_id,fence:String(item.fence),filename:item.filename});
    sql.push(stmt(env,'INSERT INTO artifacts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',aid,w.id,w.revision,item.item_id,item.attempt_id,item.fence,item.filename,key,hash,c.raw.length,meta.mime,canonical(meta),canonical({status:'PASS',validator:'bcs-byte-validator.'+PRESET_VERSION,measurements:meta,visual:'HUMAN_REVIEW_REQUIRED'}),null,now()),stmt(env,"UPDATE items SET state='VERIFYING',artifact_id=?,remote_status='OUTPUT_RECEIVED' WHERE work_id=? AND revision=? AND item_id=?",aid,w.id,w.revision,item.item_id),stmt(env,'INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?)',id(),w.id,w.revision,item.item_id,item.attempt_id,item.fence,'CP_OUTPUT',canonical({artifact_id:aid,sha256:hash,technical:'PASS'}),now()));response={artifact_id:aid,sha256:hash,state:'VERIFYING'};event={...event,...response};
   }
  }
  return {type:'ITEM_'+action.toUpperCase(),work:w.id,revision:w.revision,event,response,sql};
 });
 match=path.match(/^\/api\/artifacts\/([a-z0-9-]+)\/review$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const a=await one(env,'SELECT * FROM artifacts WHERE id=?',match[1]);if(!a)error('ARTIFACT_NOT_FOUND',404);const w=await current(env,a.work_id);if(w.revision!==a.revision||w.state!=='RUNNING')error('REVISION_OR_STATE_CONFLICT');
  const item=await one(env,'SELECT * FROM items WHERE work_id=? AND revision=? AND item_id=?',w.id,w.revision,a.item_id);if(item.artifact_id!==a.id||item.fence!==a.fence||item.state!=='VERIFYING')error('STALE_ATTEMPT');
  if(c.data.sha256!==a.sha256||['creative_reviewed','rights_reviewed','text_reviewed','continuity_reviewed'].some(k=>c.data[k]!==true))error('HUMAN_QA_REQUIRED');
  await verifiedObject(env,a.object_key,a.sha256);await verifyWorkPins(env,w);const report={...c.data,actor:actor.email,reviewed_at:now()};
  const pending=await one(env,"SELECT count(*) n FROM items WHERE work_id=? AND revision=? AND state!='QA_PASSED' AND item_id!=?",w.id,w.revision,a.item_id);
  return {type:'HUMAN_QA_RECORDED',work:w.id,revision:w.revision,event:{artifact_id:a.id,sha256:a.sha256},response:{state:pending.n?'RUNNING':'WAITING_RELEASE_APPROVAL'},sql:[stmt(env,'UPDATE artifacts SET review=? WHERE id=?',canonical(report),a.id),stmt(env,"UPDATE items SET state='QA_PASSED' WHERE work_id=? AND revision=? AND item_id=?",w.id,w.revision,a.item_id),stmt(env,'UPDATE works SET state=? WHERE id=?',pending.n?'RUNNING':'WAITING_RELEASE_APPROVAL',w.id),stmt(env,'INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?)',id(),w.id,w.revision,a.item_id,a.attempt_id,a.fence,'CP_QA',canonical({sha256:a.sha256,report}),now())]};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/(manifest|release|export)$/);
 if(match){const w=await current(env,match[1]);
  if(method==='GET'&&match[2]==='manifest')return json(await manifest(env,w));
  if(method==='POST'&&match[2]==='release')return mutation(request,env,actor,async c=>{
   const w=await current(env,match[1]);
   matchRevision(w,c.data);if(w.state!=='WAITING_RELEASE_APPROVAL')error('STATE_CONFLICT');const m=await manifest(env,w);
   if(c.data.manifest_sha256!==m.manifest_sha256||c.data.release_reviewed!==true)error('RELEASE_HASH_APPROVAL_REQUIRED');
   return {type:'RELEASE_APPROVED',work:w.id,revision:w.revision,event:{manifest_sha256:m.manifest_sha256},response:{state:'EXPORT_READY',manifest_sha256:m.manifest_sha256},sql:[stmt(env,"UPDATE works SET state='EXPORT_READY' WHERE id=?",w.id),stmt(env,'INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)',id(),'RELEASE',w.id,w.revision,m.manifest_sha256,actor.email,canonical(m),now())]};
  });
  if(method==='GET'&&match[2]==='export'){
   if(w.state!=='EXPORT_READY')error('RELEASE_APPROVAL_REQUIRED');const m=await manifest(env,w),approval=await one(env,"SELECT * FROM approvals WHERE target_id=? AND revision=? AND scope='RELEASE' ORDER BY created_at DESC LIMIT 1",w.id,w.revision);if(approval?.sha256!==m.manifest_sha256)error('RELEASE_HASH_CHANGED');
   const files={};for(const f of m.files){const a=await one(env,'SELECT * FROM artifacts WHERE id=?',f.id);files[f.name]=await verifiedObject(env,a.object_key,a.sha256);}
   const zip=zipSync(files,{level:0});if(w.data.product_type==='regular_emoji'&&zip.length>=20_000_000)error('FILE_SIZE',422);if(w.data.product_type==='animated_emoji'&&zip.length>20_000_000)error('FILE_SIZE',422);
   return new Response(zip,{headers:{'Content-Type':'application/zip','Content-Disposition':`attachment; filename="${w.id}-r${w.revision}.zip"`}});
  }
 }
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/reconcile$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]);matchRevision(w,c.data);const journal=await verifyJournal(env);const items=await all(env,'SELECT * FROM items WHERE work_id=? AND revision=?',w.id,w.revision),arts=await all(env,'SELECT * FROM artifacts WHERE work_id=? AND revision=?',w.id,w.revision);const observations=[];
  for(const a of arts){let status='VERIFIED';try{await verifiedObject(env,a.object_key,a.sha256);}catch(e){status=e.message;}observations.push({artifact_id:a.id,sha256:a.sha256,status});}
  const invalidPins=[];for(const p of w.data.input_pins){try{const a=await one(env,'SELECT * FROM assets WHERE id=?',p.asset_id);if(!a||a.sha256!==p.sha256)throw Error();await verifiedObject(env,a.object_key,p.sha256);}catch{invalidPins.push(p.asset_id);}}
  const objects=[];let cursor;do{const page=await env.BUCKET.list({prefix:`works/${w.id}/r${w.revision}/`,cursor,include:['customMetadata']});objects.push(...page.objects);cursor=page.truncated?page.cursor:undefined;}while(cursor);
  const known=new Set(arts.map(a=>a.object_key)),orphans=[];
  for(const o of objects.filter(o=>!known.has(o.key))){let verified=false;try{await verifiedObject(env,o.key,o.customMetadata?.sha256);verified=true;}catch{}orphans.push({key:o.key,sha256:o.customMetadata?.sha256,verified,action:'OWNER_REVIEW_REIMPORT_WITH_ORIGINAL_IDEMPOTENCY_KEY'});}
  const stateHash=await sha256(canonical({items,artifacts:arts.map(a=>({id:a.id,sha256:a.sha256,review:a.review})),observations,invalidPins,orphans}));const report={state_hash:stateHash,journal,items:items.map(i=>({item_id:i.item_id,state:i.state,remote_status:i.remote_status,fence:i.fence,attempt_id:i.attempt_id,expired:i.lease_until!==null?i.lease_until<Date.now():false})),observations,invalid_pins:invalidPins,orphans,automatic_retry:false},rid=id();
  return {type:'RECOVERY_RECONCILIATION',work:w.id,revision:w.revision,event:{reconciliation_id:rid,state_hash:stateHash},response:{id:rid,...report},sql:[stmt(env,'INSERT INTO reconciliations VALUES(?,?,?,?,?)',rid,w.id,w.revision,canonical(report),now())]};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/items\/([a-z0-9]+)\/retry$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]),item=await itemFor(env,w,match[2],c.data);if(w.state==='CANCELLED'||item.state==='QA_PASSED')error('RETRY_NOT_ALLOWED');if(item.retries>=2)error('RETRY_LIMIT');
  const r=await one(env,'SELECT * FROM reconciliations WHERE id=? AND work_id=? AND revision=?',c.data.reconciliation_id||'',w.id,w.revision);if(!r)error('RECONCILE_BEFORE_RETRY');
  const latest=await one(env,'SELECT id FROM reconciliations WHERE work_id=? AND revision=? ORDER BY created_at DESC LIMIT 1',w.id,w.revision);const report=parse(r.report);
  if(latest?.id!==r.id||Date.now()-Date.parse(r.created_at)>60_000||report.journal.events+1!==c.control.version)error('RECONCILIATION_STALE');if(report.invalid_pins.length||report.observations.some(a=>a.status!=='VERIFIED')||report.orphans.length)error('RECOVERY_INTEGRITY_BLOCKED');
  if(item.artifact_id)error('EXISTING_OUTPUT_REVIEW_INSTEAD');
  const observed=report.items.find(i=>i.item_id===item.item_id);if(!observed||observed.state!==item.state||observed.remote_status!==item.remote_status||observed.fence!==item.fence||observed.attempt_id!==item.attempt_id)error('RECONCILIATION_STALE');
  if(item.state==='RUNNING'&&item.lease_until>Date.now())error('LEASE_STILL_ACTIVE');
  if(item.remote_status==='UNKNOWN_REMOTE')error('UNKNOWN_REMOTE_REQUIRES_RECEIPT_NO_BLIND_RETRY');
  if(c.data.confirm_no_remote_action!==true||typeof c.data.evidence!=='string'||c.data.evidence.trim().length<10)error('RETRY_OWNER_EVIDENCE_REQUIRED');await verifyWorkPins(env,w);
  return {type:'SAFE_RETRY_APPROVED',work:w.id,revision:w.revision,event:{item_id:item.item_id,reconciliation_id:r.id,evidence:c.data.evidence,source:'OWNER_ATTESTATION'},response:{state:'READY',fence:item.fence+1},sql:[stmt(env,"UPDATE items SET state='READY',fence=fence+1,retries=retries+1,attempt_id=NULL,lease_owner=NULL,lease_until=NULL WHERE work_id=? AND revision=? AND item_id=?",w.id,w.revision,item.item_id),stmt(env,"UPDATE works SET state='READY' WHERE id=?",w.id)]};
 });
 match=path.match(/^\/api\/works\/([A-Za-z0-9-]+)\/items\/([a-z0-9]+)\/restore-lease$/);
 if(method==='POST'&&match)return mutation(request,env,actor,async c=>{
  const w=await current(env,match[1]),item=await itemFor(env,w,match[2],c.data);
  if(item.state!=='RUNNING'||!item.attempt_id||!['RUNNING','PAUSED'].includes(w.state))error('EXISTING_ATTEMPT_REQUIRED');
  if(c.data.confirm_resume_existing_attempt!==true||typeof c.data.evidence!=='string'||c.data.evidence.trim().length<10)error('RESUME_OWNER_EVIDENCE_REQUIRED');
  const r=await one(env,'SELECT * FROM reconciliations WHERE id=? AND work_id=? AND revision=?',c.data.reconciliation_id||'',w.id,w.revision);if(!r||Date.now()-Date.parse(r.created_at)>60_000)error('RECONCILE_BEFORE_RESUME');const report=parse(r.report);if(report.journal.events+1!==c.control.version)error('RECONCILIATION_STALE');
  if(report.invalid_pins.length||report.observations.some(a=>a.status!=='VERIFIED')||report.orphans.length)error('RECOVERY_INTEGRITY_BLOCKED');
  const observed=report.items.find(i=>i.item_id===item.item_id);if(observed?.state!==item.state||observed?.remote_status!==item.remote_status||observed?.fence!==item.fence||observed?.attempt_id!==item.attempt_id)error('RECONCILIATION_STALE');await verifyWorkPins(env,w);
  return {type:'EXISTING_ATTEMPT_LEASE_RESTORED_NO_REDISPATCH',work:w.id,revision:w.revision,event:{item_id:item.item_id,attempt_id:item.attempt_id,fence:item.fence,evidence:c.data.evidence},response:{attempt_id:item.attempt_id,fence:item.fence,lease_until:Date.now()+180000,redispatched:false},sql:[stmt(env,"UPDATE works SET state='RUNNING' WHERE id=?",w.id),stmt(env,'UPDATE items SET lease_until=? WHERE work_id=? AND revision=? AND item_id=?',Date.now()+180000,w.id,w.revision,item.item_id)]};
 });
 if(method==='GET'&&path==='/api/journal')return json(await all(env,'SELECT * FROM events ORDER BY seq'));
 if(method==='GET'&&path==='/api/backup'){
  const tables=['control','commands','events','assets','works','revisions','items','artifacts','checkpoints','approvals','reconciliations'];const records={};const snapshot=await env.DB.batch(tables.map(t=>env.DB.prepare('SELECT * FROM '+t)));tables.forEach((t,i)=>records[t]=snapshot[i].results);
  const files={'control-snapshot.json':strToU8(canonical({schema_version:'1.0',created_at:now(),records}))};let total=0;
  for(const a of [...records.assets,...records.artifacts]){total+=a.size;if(total>20_000_000)error('BACKUP_TOO_LARGE_USE_ADMIN_R2_EXPORT',413);files['objects/'+a.id]=await verifiedObject(env,a.object_key,a.sha256);}
  return new Response(zipSync(files,{level:0}),{headers:{'Content-Type':'application/zip','Content-Disposition':'attachment; filename="bcs-private-backup.zip"'}});
 }
 if(path.endsWith('/publish')||path.includes('/grok-api')||path.endsWith('/generate'))error('EXPORT_ONLY_NO_GENERATION_API',403);
 error('NOT_FOUND',404);
}
function secure(response){const out=new Response(response.body,response);for(const [k,v] of Object.entries({'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"}))out.headers.set(k,v);return out;}
export default {
 async fetch(request,env){
  try{
   const url=new URL(request.url);
   if(!['GET','HEAD'].includes(request.method)&&(request.headers.get('Origin')!==url.origin||request.headers.get('X-BCS-Intent')!=='write'))return secure(json({error:'SAME_ORIGIN_WRITE_REQUIRED'},403));
   if(url.pathname==='/auth/local-login'&&request.method==='POST')return secure(await localLogin(request,env));
   const actor=await authenticate(request,env);
   if(!actor){
    if(isLocal(request,env)&&['/','/index.html','/app.js','/styles.css'].includes(url.pathname)&&request.method==='GET')return secure(await env.ASSETS.fetch(request));
    return secure(json({error:'AUTHENTICATION_REQUIRED'},401));
   }
   if(url.pathname==='/auth/local-logout'&&request.method==='POST')return secure(new Response('{}',{headers:{'Content-Type':'application/json','Set-Cookie':'bcs_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'}}));
   if(url.pathname.startsWith('/api/'))return secure(await api(request,env,actor));
   if(['GET','HEAD'].includes(request.method))return secure(await env.ASSETS.fetch(request));
   return secure(json({error:'METHOD_NOT_ALLOWED'},405));
  }catch(e){return secure(json({error:e.status?e.message:'INTERNAL_ERROR',retry_safe:false},e.status||500));}
 }
};
