import {decode,convertIndexedToRgb} from 'fast-png';
import {unzlibSync} from 'fflate';
import jpeg from 'jpeg-js';
export const PRESET_VERSION='2026-10-13.v2';
export const hex=bytes=>Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');
export const sha256=async data=>hex(await crypto.subtle.digest('SHA-256',typeof data==='string'?new TextEncoder().encode(data):data));
export function canonical(v){if(Array.isArray(v))return '['+v.map(canonical).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';return JSON.stringify(v);}
function fail(code){const e=new Error(code);e.status=422;throw e;}
const signature=Buffer.from([137,80,78,71,13,10,26,10]);
export function crc32(bytes){let c=0xffffffff;for(const x of bytes){c^=x;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
export function chunk(type,data){const name=Buffer.from(type),b=Buffer.alloc(data.length+12);b.writeUInt32BE(data.length);name.copy(b,4);Buffer.from(data).copy(b,8);b.writeUInt32BE(crc32(b.subarray(4,b.length-4)),b.length-4);return b;}
function bounded(w,h){if(w<1||h<1||w>2048||h>2048||w*h>2_000_000)fail('IMAGE_RESOURCE_LIMIT');}
function pngChunks(buf){
 let at=8,chunks=[];while(at<buf.length){
  if(at+12>buf.length)fail('PNG_TRUNCATED');const n=buf.readUInt32BE(at);if(at+12+n>buf.length)fail('PNG_TRUNCATED');
  const type=buf.toString('ascii',at+4,at+8),data=buf.subarray(at+8,at+8+n);if(crc32(buf.subarray(at+4,at+8+n))!==buf.readUInt32BE(at+8+n))fail('PNG_CRC');
  chunks.push({type,data});at+=12+n;if(type==='IEND'){if(n||at!==buf.length)fail('PNG_TRAILING_DATA');break;}
 }
 if(chunks[0]?.type!=='IHDR'||chunks.at(-1)?.type!=='IEND'||chunks.filter(c=>c.type==='IHDR').length!==1||chunks[0].data.length!==13)fail('PNG_STRUCTURE');
 return chunks;
}
function decodeRGBA(chunks){
 const ihdr=chunks[0].data,w=ihdr.readUInt32BE(0),h=ihdr.readUInt32BE(4),channels=ihdr[9]===6?4:ihdr[9]===2?3:1;bounded(w,h);
 if(chunks.some(c=>c.type==='iCCP'))fail('ICCP_PROFILE_NOT_SUPPORTED_USE_SRGB');
 let expected=0;if(ihdr[12]===0)expected=h*(w*channels+1);else if(ihdr[12]===1){for(const [x,y,sx,sy] of [[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]){const pw=Math.max(0,Math.ceil((w-x)/sx)),ph=Math.max(0,Math.ceil((h-y)/sy));if(pw&&ph)expected+=ph*(pw*channels+1);}}else fail('DECODE_FAILED');
 const compressed=Buffer.concat(chunks.filter(c=>c.type==='IDAT').map(c=>c.data));const raw=unzlibSync(compressed,{out:new Uint8Array(expected+1)});if(raw.length!==expected)fail('PNG_INFLATE_LENGTH');
 let a=1,b=0;for(const x of raw){a=(a+x)%65521;b=(b+a)%65521;}if(((b*65536+a)>>>0)!==compressed.readUInt32BE(compressed.length-4))fail('PNG_ZLIB_CHECKSUM');
 const safe=chunks.filter(c=>['IHDR','PLTE','tRNS','IDAT','IEND'].includes(c.type));const image=decode(Buffer.concat([signature,...safe.map(c=>chunk(c.type,c.data))]),{checkCrc:true});
 const rgb=image.palette?convertIndexedToRgb(image):image.data,n=image.palette?image.palette[0].length:image.channels,out=Buffer.alloc(w*h*4);
 for(let i=0;i<w*h;i++){for(let k=0;k<3;k++)out[i*4+k]=rgb[i*n+k];out[i*4+3]=n===4?rgb[i*n+3]:image.transparency&&[0,1,2].every(k=>rgb[i*n+k]===image.transparency[k])?0:255;}
 return {data:out};
}
export async function inspectImage(bytes,name){
 const buf=Buffer.from(bytes);if(!buf.length||buf.length>2_000_000)fail('FILE_SIZE');
 const ext=name.toLowerCase().split('.').at(-1);
 if(buf.subarray(0,8).equals(signature)){
  if(ext!=='png')fail('MAGIC_MISMATCH');const chunks=pngChunks(buf),ihdr=chunks[0].data,w=ihdr.readUInt32BE(0),h=ihdr.readUInt32BE(4);bounded(w,h);
  if(![2,3,6].includes(ihdr[9])||ihdr[8]!==8)fail('RGB_8BIT_REQUIRED');
  let image;try{image=decodeRGBA(chunks);}catch(e){if(e.status)throw e;fail('DECODE_FAILED');}
  const transparent=data=>{for(let i=3;i<data.length;i+=4)if(data[i]<255)return true;return false;};
  const act=chunks.filter(c=>c.type==='acTL');let meta={format:'PNG_STATIC',mime:'image/png',width:w,height:h,transparent:transparent(image.data),frames:1,plays:0,cycle_ms:0,total_ms:0,motion:false};
  if(!act.length)return meta;
  if(act.length!==1||act[0].data.length!==8||chunks.findIndex(c=>c.type==='acTL')>chunks.findIndex(c=>c.type==='IDAT'))fail('APNG_STRUCTURE');
  const frames=act[0].data.readUInt32BE(0),plays=act[0].data.readUInt32BE(4);if(frames<1||frames>20)fail('FRAME_COUNT');
  const globals=chunks.filter(c=>['PLTE','tRNS','sRGB','gAMA','cHRM','iCCP','pHYs'].includes(c.type));let controls=[],current=null,seq=0,idat=false;
  for(const c of chunks){
   if(c.type==='fcTL'){
    if(c.data.length!==26||c.data.readUInt32BE(0)!==seq++)fail('APNG_SEQUENCE');
    current={data:c.data,parts:[]};controls.push(current);
   }else if(c.type==='IDAT'){
    if(!current||controls.length!==1)fail('APNG_DEFAULT_FRAME_REQUIRED');current.parts.push(c.data);idat=true;
   }else if(c.type==='fdAT'){
    if(!current||!idat||c.data.length<5||c.data.readUInt32BE(0)!==seq++)fail('APNG_SEQUENCE');current.parts.push(c.data.subarray(4));
   }
  }
  if(controls.length!==frames)fail('FRAME_COUNT');const canvas=Buffer.alloc(w*h*4);let num=0n,den=1n;const hashes=new Set();let alpha=true;
  const gcd=(a,b)=>{while(b){const x=a%b;a=b;b=x;}return a;};
  for(const f of controls){
   const d=f.data,fw=d.readUInt32BE(4),fh=d.readUInt32BE(8),x=d.readUInt32BE(12),y=d.readUInt32BE(16);bounded(fw,fh);
   if(x+fw>w||y+fh>h||d[24]>2||d[25]>1||!f.parts.length)fail('APNG_FRAME_BOUNDS');
   const fn=d.readUInt16BE(20),fd=d.readUInt16BE(22)||100;if(!fn)fail('PLAYBACK_TIME');num=num*BigInt(fd)+BigInt(fn)*den;den*=BigInt(fd);const g=gcd(num,den);num/=g;den/=g;
   const header=Buffer.from(ihdr);header.writeUInt32BE(fw,0);header.writeUInt32BE(fh,4);let frame;
   try{frame=decodeRGBA([{type:'IHDR',data:header},...globals,{type:'IDAT',data:Buffer.concat(f.parts)},{type:'IEND',data:Buffer.alloc(0)}]);}catch(e){if(e.status)throw e;fail('DECODE_FAILED');}
   const prior=Buffer.from(canvas);
   for(let py=0;py<fh;py++)for(let px=0;px<fw;px++){
    const a=(py*fw+px)*4,b=((y+py)*w+x+px)*4;
    if(d[25]===0){frame.data.copy(canvas,b,a,a+4);}else{
     const sa=frame.data[a+3]/255,da=canvas[b+3]/255,oa=sa+da*(1-sa);
     for(let k=0;k<3;k++)canvas[b+k]=oa?Math.round((frame.data[a+k]*sa+canvas[b+k]*da*(1-sa))/oa):0;
     canvas[b+3]=Math.round(oa*255);
    }
   }
   hashes.add(await sha256(canvas));alpha=alpha&&transparent(canvas);
   if(d[24]===1){for(let py=0;py<fh;py++)canvas.fill(0,((y+py)*w+x)*4,((y+py)*w+x+fw)*4);}else if(d[24]===2)prior.copy(canvas);
  }
  return {...meta,format:'APNG',frames,plays,cycle_ms:Number(num)*1000/Number(den),total_ms:Number(num*BigInt(plays))*1000/Number(den),cycle_whole:num%den===0n,total_whole:(num*BigInt(plays))%den===0n,motion:hashes.size>1,transparent:alpha};
 }
 if(buf[0]===255&&buf[1]===216&&buf[2]===255){
  if(!['jpg','jpeg'].includes(ext))fail('MAGIC_MISMATCH');let im;try{im=jpeg.decode(buf,{useTArray:true,maxResolutionInMP:2,maxMemoryUsageInMB:32});}catch{fail('DECODE_FAILED');}bounded(im.width,im.height);
  return {format:'JPEG',mime:'image/jpeg',width:im.width,height:im.height,transparent:false,frames:1};
 }
 fail('UNSUPPORTED_IMAGE');
}
export const TYPES={creative:['series_script','sticker_ideas'],character:['master_image','wardrobe_image'],line:['static_sticker','animated_sticker','regular_emoji','animated_emoji','theme'],social:['social_image'],grok:['storyboard','prompt_text'],publishing:['content_package']};
export function presetFor(data){
 const base={version:PRESET_VERSION,product_type:data.product_type,primary_count:data.count,max_upload_bytes:2_000_000,max_image_pixels:2_000_000,package_application_limit_bytes:20_000_000,exact_text:data.exact_text||'',human_review_required:true};
 if(data.module==='line'){
  const t=data.product_type,animated=t.startsWith('animated'),emoji=t.includes('emoji');
  if(t==='theme')return {...base,status:'BLOCKED_SPEC_UNVERIFIED'};
  return {...base,primary:{format:animated?'APNG_IN_PNG':'PNG_STATIC',dimensions:emoji?{exact:[180,180]}:animated?{max:[320,270],at_least_one_side_min:270}:{max:[370,320],even_dimensions:true},transparent:true,max_bytes:t==='animated_emoji'?300_000:1_000_000},main:emoji?null:{format:animated?'APNG_IN_PNG':'PNG_STATIC',exact:[240,240],transparent:true},tab:{format:'PNG_STATIC',exact:[96,74],transparent:true,max_bytes:t==='animated_emoji'?300_000:1_000_000},animation:animated?{frames:[5,20],plays:[1,4],cycle_whole_seconds:[1,2,3,4],total_whole_seconds_max:4,motion_required:true,default_image_in_animation:true}:null,platform_zip_limit_bytes:emoji?20_000_000:60_000_000,platform_zip_strict_less_than:t==='regular_emoji',sources:['https://creator.line.me/en/guideline/'+(t==='static_sticker'?'sticker':t==='animated_sticker'?'animationsticker':t==='regular_emoji'?'emoji':'animationemoji')+'/']};
 }
 return {...base,primary:{format:data.format==='md'?'UTF8_MARKDOWN':data.format==='jpg'?'JPEG':'PNG_STATIC',exact:data.format==='md'?null:[data.width,data.height]},companions:data.module==='social'?['captions.md','hashtags.md']:[],execution:'MANUAL_WORK_HANDOFF',grok_video_allowed:false,publish_allowed:false};
}
export function normalizeIntake(body){
 const module=String(body.module||''),type=String(body.product_type||''),count=Number(body.count);
 if(!TYPES[module]?.includes(type))fail('TYPE_MISSING');if(!Number.isInteger(count)||count<1||count>40)fail('PACK_COUNT');
 if(type==='static_sticker'&&![8,16,24,32,40].includes(count))fail('PACK_COUNT');
 if(type==='animated_sticker'&&![8,16,24].includes(count))fail('PACK_COUNT');
 if(['regular_emoji','animated_emoji'].includes(type)&&count<8)fail('PACK_COUNT');
 if(!['Single','Auto'].includes(body.mode||'Single'))fail('MULTI_WORKER_NOT_VERIFIED');
 for(const field of ['title','brief','audience','language'])if(typeof body[field]!=='string'||!body[field].trim()||body[field].length>6000)fail('INTAKE_MISSING_'+field.toUpperCase());
 if(body.paid_api||body.generate_video||body.publish)fail('EXPORT_ONLY');
 const image=!['series_script','sticker_ideas','storyboard','prompt_text','content_package'].includes(type);
 const pins=body.asset_ids||[];if(!Array.isArray(pins)||pins.length>12||pins.some(x=>typeof x!=='string'))fail('INVALID_PINS');
 if((module==='line'||type==='wardrobe_image')&&!pins.length)fail('APPROVED_SOURCE_REQUIRED');
 const format=image?(body.format||'png'):'md';if(!['png','jpg','md'].includes(format))fail('INVALID_FORMAT');
 if(module==='line'&&format!=='png')fail('LINE_PNG_REQUIRED');
 const width=Number(body.width||1024),height=Number(body.height||1024);bounded(width,height);
 const sourceWorks=body.source_work_ids||[];if(!Array.isArray(sourceWorks)||sourceWorks.length>8||sourceWorks.some(x=>typeof x!=='string'))fail('INVALID_RELEASE_SOURCES');
 if(module==='publishing'&&!sourceWorks.length)fail('APPROVED_RELEASE_REQUIRED');
 return {module,product_type:type,count,mode:body.mode||'Single',title:body.title.trim(),brief:body.brief.trim(),audience:body.audience.trim(),language:body.language.trim(),exact_text:String(body.exact_text||'').slice(0,6000),asset_ids:[...new Set(pins)],source_work_ids:[...new Set(sourceWorks)],format,width,height,preset_version:PRESET_VERSION,paid_api:false,automatic_generation:false,publishing:false};
}
export function makeItems(data){
 const items=Array.from({length:data.count},(_,i)=>({id:String(i+1).padStart(3,'0'),role:'primary',filename:data.module==='line'?String(i+1).padStart(data.product_type.includes('emoji')?3:2,'0')+'.png':String(i+1).padStart(3,'0')+'.'+data.format}));
 if(data.module==='line'&&data.product_type!=='theme'){
  if(data.product_type.includes('sticker'))items.push({id:'main',role:'main',filename:'main.png'});
  items.push({id:'tab',role:'tab',filename:'tab.png'});
 }
 if(data.module==='social')items.push({id:'captions',role:'caption',filename:'captions.md'},{id:'hashtags',role:'hashtags',filename:'hashtags.md'});
 return items;
}
export async function inspectOutput(bytes,name,data,role){
 const type=data.product_type;
 if(['caption','hashtags'].includes(role)||['series_script','sticker_ideas','storyboard','prompt_text','content_package'].includes(type)){
  if(!name.endsWith('.md')||bytes.length>100_000||!bytes.length)fail('TEXT_FORMAT');let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{fail('TEXT_UTF8');}
  if(data.exact_text&&role!=='hashtags'&&!text.includes(data.exact_text))fail('TEXT_MISMATCH');return {format:'UTF8_MARKDOWN',mime:'text/markdown',characters:text.length,technical:'PASS',visual:'HUMAN_REVIEW_REQUIRED'};
 }
 if(type==='theme')fail('THEME_SPEC_UNVERIFIED');const m=await inspectImage(bytes,name);
 if(data.module==='line'){
  const animated=type.startsWith('animated')&&role!=='tab';if(m.format!==(animated?'APNG':'PNG_STATIC'))fail(animated?'APNG_REQUIRED':'STATIC_REQUIRED');
  if(bytes.length>(type==='animated_emoji'?300_000:1_000_000))fail('FILE_SIZE');if(!m.transparent)fail('ALPHA_POLICY');
  if(role==='tab'){if(m.width!==96||m.height!==74)fail('DIMENSION');}
  else if(role==='main'){if(m.width!==240||m.height!==240)fail('DIMENSION');}
  else if(type.includes('emoji')){if(m.width!==180||m.height!==180)fail('DIMENSION');}
  else if(animated){if(m.width>320||m.height>270||Math.max(m.width,m.height)<270)fail('DIMENSION');}
  else if(m.width>370||m.height>320||m.width%2||m.height%2)fail('DIMENSION');
  if(animated){if(m.frames<5||m.frames>20)fail('FRAME_COUNT');if(m.plays<1||m.plays>4)fail('LOOP_COUNT');if(!m.cycle_whole||!m.total_whole||m.cycle_ms<1000||m.total_ms>4000)fail('PLAYBACK_TIME');if(!m.motion)fail('NO_MOTION');}
 }else{
  if(m.format!==(data.format==='jpg'?'JPEG':'PNG_STATIC'))fail('MAGIC_MISMATCH');if(m.width!==data.width||m.height!==data.height)fail('DIMENSION');
 }
 return {...m,technical:'PASS',visual:'HUMAN_REVIEW_REQUIRED'};
}
