# Workflow rules — implemented web control

## Intake, revision and pins

เลือก module/product_type/count/title/brief/audience/language/mode ก่อนสร้าง LINE subtype/count ต้องตรงกฎ; wardrobeและLINEต้องเลือก approved R2 source; publishingต้องเลือก approved release ไม่ใช้แค่ชื่อไฟล์/latest

Serverสร้าง Work ID จาก command identity, revision1, item roles/filenames, full format_rules snapshot + preset hash, intake hash และ asset/release pins ทุก revision ใหม่มี intake/preset/pins ใหม่ ไม่ยืม PLAN/RELEASE approvalเก่า outputs revisionเก่ายังอยู่และ historical approved releaseที่ pinไว้ยัง exportในpackageอื่นได้

Profile ปัจจุบัน `2026-10-13.v2` Claimที่ใช้ profileเก่าถูกบล็อกให้สร้าง reviewed revision ใหม่ ไม่อ้างว่ารัน validatorเก่าทุกรุ่นได้

## States and owner actions

```text
PLANNED --approve-plan--> READY --claim item--> RUNNING
item RUNNING --output import/byte validation--> VERIFYING
item VERIFYING --owner Human QA--> QA_PASSED
all required items QA_PASSED --> WAITING_RELEASE_APPROVAL
owner approve exact manifest SHA256 --> EXPORT_READY
nonterminal --pause/cancel--> PAUSED / CANCELLED
```

ผิด state/revision/attempt/fence/lease → reject ไม่เงียบข้าม gate; QAไม่ผ่านนำเข้าไม่ได้และเก็บerrorให้ownerแก้ต้นเหตุ ไม่มี image generation fallback

Single = หนึ่ง active item ต่อ Work; Auto = ลำดับที่เสนอให้ Workทำภายใต้activeinvocation/ownerapproval ไม่ใช่ schedulerในเว็บ; Multi-worker intake rejectด้วย MULTI_WORKER_NOT_VERIFIED ไม่มีการสร้าง workerแฝง

## Checkpoint and lease

Claimสร้าง attemptUUID/fenceเพิ่ม/lease180s พร้อม CP_PLAN ที่มี pins/preset/expectedfilename UIต่อ heartbeatทุก45s เมื่อยังเปิดรายละเอียดและactive; browserปิดหรือbackgroundอาจหยุด heartbeat

Ownerบันทึก CP_DISPATCH/CP_RECEIPT/CP_NOTE พร้อมหลักฐานจริง ผู้ใช้ต้องระบุสถานะ UNKNOWN_REMOTE เมื่อไม่รู้ว่าWorkดำเนินต่อหรือไม่ ไม่ถือว่า leaseหมดคือ remote actionหยุด

Outputนำกลับต้องชื่อ/format/role/currentattemptถูกต้อง มี actual bytes/hash/decoder measurements; บันทึก CP_OUTPUT หลัง R2readback/D1commit; ownerreviewครบ→CP_QA ไม่ใช้การติ๊ก Human QAเป็นหลักฐานว่าระบบอ่านภาพด้วยAIจริง

## Recovery

กดตรวจและกู้คืน: อ่าน current revision/items/receipts, hash R2 artifacts/pins และ list staged objects ระบุ corrupt/missing/orphan/expired/unknownในreport ไม่มีautoretry

- outputมีแล้ว → ตรวจ/ทำQAต่อ ไม่rerun generator
- unknown remote → retryถูกบล็อก ต้องหาresult/receiptจริงก่อน
- pause/expired attemptที่ยังมีผลเดิม → หลัง reconcile และownerยืนยัน คืนleaseของattempt/fenceเดิมเพื่อรับผล ไม่redispatch
- known no remote action / no output → freshreconciliation≤60s, ownerevidence+confirmation, no activelease/corruption/orphans แล้วจึงretry; fenceเพิ่มและจำกัด2retries
- cancelled/stale output → reject; bytesเก่าไม่ถูกpromoteหรือลบ

Owner attestationsในmanualbridgeเป็นข้อมูลจากผู้ใช้ ไม่ใช่การqueryสถานะWorkอัตโนมัติ ไม่มี exactly-once guaranteeของexternal generation

## Approvals and export

Master: preview/rights + exact asset SHA256; new derivativeเป็นDRAFTใหม่ไม่overwrite parent Release: input/preset/intake hash + sorted output hash setครบทุกrequireditem การเปลี่ยนbrief/text/revisionต้องตรวจและอนุมัติใหม่

ExportตรวจR2hashesและapprovalhashอีกครั้ง ZIPแพลตฟอร์มใส่เฉพาะpayload ไม่มีQA JSONปน Manifestดาวน์โหลดแยก Publishingรวมpayloadของapproved revisionsที่pinไว้พร้อม checklistของงานนี้ ห้ามให้เว็บโพสต์หรือเรียกPaid/Grok API

API route `/generate`, `/publish`, `/grok-api` ปฏิเสธ สิทธิ์Planapprovalไม่ใช่productionAIusageauthorization การทดลองในrepoนี้ใช้geometry/textfixturesเท่านั้น
