# Implemented file format rules

อ้างอิงข้อกำหนด Greenfield/LINE ทางการที่ตรวจ 13 ตุลาคม 2026 รูปทั่วไปใช้ PNG static/JPEG; captions/prompts/scriptsใช้UTF-8 Markdown Validatorตรวจbytesจริง ไม่อ่าน MIME/นามสกุลแล้วให้PASS

| LINE subtype | Primary | Main / Tab | จำนวน |
|---|---|---|---|
| Static Sticker | transparent PNG ≤370×320, even width/height | main240×240 static; tab96×74 static | 8/16/24/32/40 |
| Animated Sticker | APNG .png ≤320×270, มีด้าน≥270 | main240×240 APNG; tab96×74 static | 8/16/24 |
| Regular Emoji | transparent static PNG180×180, 001..NNN.png | tab96×74 static | 8–40 |
| Animated Emoji | transparent APNG .png180×180, 001..NNN.png | tab96×74 static | 8–40 |
| Theme | ต้องมีcurrentfile/OS/alpha manifest | ยังBLOCKED | ไม่hardcode |

Per-file cap 1,000,000 bytes; Animated Emojiทุกroleรวมtab≤300,000 bytes; staticEmoji ZIP<20,000,000; animatedEmojiZIP≤20,000,000; StickerplatformZIP≤60,000,000 แต่appมีpackage/backup resourcecap20,000,000 จึงเข้มกว่ากฎplatformบางกรณี

APNGตรวจchunkCRC/sequence/acTL/framecount5–20, actualdecodedcompositedmotion, plays1–4 (0reject), rationaldelays→integercycleและtotal1–4s, defaultimageอยู่ในanimation, bounds/alphaทุกframe Main/tabแยกชนิดไฟล์ ไม่renameGIF/WebP/MP4ให้เป็นPNG

รองรับ PNG RGB/RGBA/indexed **8-bit** พร้อมtRNSและAdam7; ไม่รองรับgrayscale/16-bit/ICCcompressedprofileในรุ่นนี้ ให้convertเป็นsRGBผ่านเครื่องมือที่มีจริงก่อนนำเข้าไม่ใช่เปลี่ยนนามสกุล InflatedpayloadpreflightจำกัดตามIHDR+scanlinesตรวจAdler32, CRCทุกchunk และfulldecodeก่อนpixelQA ป้องกันการallocateภาพตามbytesที่ไม่จำกัด

max upload2MB, max2MPและด้านไม่เกิน2048; UTF8Markdown≤100KB; committedstoragecap100MB (ไม่รวมstagedorphans) ไม่มีMP4/GIF/SVG/ZIPimport ไม่ได้มีตัวสร้างAPNG/วิดีโอในproductionเว็บ แต่รับ/validateAPNGที่Workหรือเครื่องมือภายนอกทำได้

ExactThai: textfileต้องมีexactstringที่ระบุ; ภาพมีtextlayermanifestในintakeและownerproof gate OCR/การตรวจตัวอักษรในpixelsอัตโนมัติยังไม่ทำ จึงห้ามอ้างhumanvisualQAผ่านจากbytevalidator

ThemeถูกblockเพราะรายการตามOS/เวอร์ชัน/alphaยังไม่reconcileครบ ไม่ทำprofileจากpresetSticker ตัวอย่างThemethumbnailต้องopaqueกฎนี้จึงไม่ใช่transparentทุกLINEasset

Sources: [Sticker](https://creator.line.me/en/guideline/sticker/), [Animated Sticker](https://creator.line.me/en/guideline/animationsticker/), [Emoji](https://creator.line.me/en/guideline/emoji/), [Animated Emoji](https://creator.line.me/en/guideline/animationemoji/), [Theme detail](https://creator.line.me/en/guideline/theme/detail/), [PNG/APNG standard](https://www.w3.org/TR/png-3/)
