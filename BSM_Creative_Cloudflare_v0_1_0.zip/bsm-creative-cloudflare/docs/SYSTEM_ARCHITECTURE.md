# System architecture — native Cloudflare

รุ่น 0.1.0 · 13 ตุลาคม 2026 · โครงการใหม่จากศูนย์ ใช้ design audit ล่าสุดเป็นข้อกำหนด โดยปรับ **Google Drive → R2** อย่างชัดเจน ไม่ย้ายภาพหรือข้อมูลใดจากระบบเก่า

```mermaid
flowchart TD
  U[เจ้าของ: Chrome / Android / Windows] --> A[Cloudflare Access: email policy + OTP]
  A --> W[Workers: JWT owner check + same-origin writes]
  W --> S[Static responsive UI]
  W --> D[D1: state / versioned intake / approvals / journal]
  W --> R[R2 private: immutable content-addressed objects]
  U --> H[Download Work handoff + attach pinned images]
  H --> X[ChatGPT Work: external/manual execution]
  X --> I[Owner imports result files / receipts]
  I --> W
  W --> Q[Byte QA → Human QA → hash-bound release]
  Q --> Z[Private export ZIP]
```

Web and API ใช้ origin เดียว static assets ตั้ง `run_worker_first=true` เพื่อไม่ให้ข้าม auth R2 ไม่มี public URL ภาพผ่าน authenticated `/api/assets/:id/file` เท่านั้น ไม่ใช้ KV/localStorage เป็นฐานข้อมูลงาน

## ขอบเขตโมดูล

| โมดูล | การทำงานในเว็บ | การผลิตสื่อ |
|---|---|---|
| Creative Lab | intake/script/idea items, checkpoints, Markdown import/export | Work ภายนอกหลังผู้ใช้อนุมัติ |
| Character & Image | registry, approved pins, derivative lineage, PNG/JPEG results | Work ภายนอก; ไม่รับรอง identity จาก generator |
| LINE | typed item/companion roles, actual PNG/APNG validator, ZIP | Work ภายนอก; Theme BLOCKED |
| Social | image + captions.md + hashtags.md เป็นคนละรายการ | Work ภายนอก; export-only |
| Grok Prompt | storyboard/prompt Markdown; no API/video route | ผู้ใช้ใช้ Grok app เองภายหลัง ไม่ใช่งานของเว็บ |
| Publishing | pin approved release revision/hash + delivery checklist → combined ZIP | ไม่มีการโพสต์จริง |

## สถานะและ atomicity

D1 tables: control, transaction_guard, commands, events, assets, works, revisions, items, artifacts, checkpoints, approvals, reconciliations

Control record มี version/head hash; mutation อ่าน snapshot → prepared changes → D1 batch ที่เริ่มด้วย NOT NULL transaction guard เปรียบเทียบ version/hash → changes/journal/idempotency cache → update head → remove guard ใน transaction เดียว Stale mutation rollback แล้วตอบ 409 เจ้าของต้อง refresh ไม่ auto-retry mutation ที่ไม่ทราบผล

R2 กับ D1 ไม่ใช่ transaction เดียว: stage key ที่มี work/revision/item/attempt/command/content hash → conditional put → readback SHA256 → D1 commit หาก DB commit ไม่ได้ object อาจเป็น orphan; reconciliation list/hash ให้ owner ตรวจ ไม่มีการลบหรือส่งซ้ำโดยเดา

มี single owner เท่านั้น ไม่ใช่ worker-auth API เจ้าของเป็นผู้บันทึกผลผ่านเว็บ Work ไม่ได้รับ token หรือสิทธิ์ mutation ในระบบ จึงยังไม่เปิด Multi-worker จริง แม้ concurrent HTTP claim serialization ทดสอบแล้ว

## Authentication

Production: ตรวจ `Cf-Access-Jwt-Assertion` ด้วย JWKS ของ team ที่ config, RS256 signature, issuer, audience, expiry และ exact owner email ไม่เชื่อ email header ลอย ๆ Environment/config/token ที่ขาด fail-closed ไม่ใช้ DEV token บน production หรือ hostnameภายนอก

Local: development + HTTP loopback เท่านั้น; random DEV_LOGIN_TOKEN/DEV_SESSION_SECRET ใน `.dev.vars` private; HMAC session HttpOnly/SameSite=Strict ไม่ใส่ Secure สำหรับ local HTTP Productionใช้ Access cookie ที่ gatewayจัดการ ไม่ออก custom DEV session แทน

POST ต้อง Originตรง origin ของ request + X-BCS-Intent=write ป้องกัน CSRF; responses no-store/nosniff/no-referrer/frame-ancestors none; UI escape ข้อมูลที่ผู้ใช้ป้อน ไม่มี public R2/CORS allowance

## สถานะที่พิสูจน์แล้วและข้อจำกัด

API/state/storage ใน workerd/Miniflare: PASS ตามรายงาน Production JWT route ใช้ RSA จริงและ simulated JWKS: PASS เฉพาะตรรกะ/runtime ไม่ใช่ real Cloudflare OTP

Deploy, actual Cloudflare bindings, OTP/email delivery, browserบนเครื่องผู้ใช้ และ Free CPU limits: NOT TESTED ไม่มี URL cloud ที่ยืนยันได้ ไม่มี background media worker/Grok/Paid API การผลิตภาพ/identity/Thai visual proofsจริงต้องทดสอบใน Workแยก

ดู [Cloudflare static routing](https://developers.cloudflare.com/workers/static-assets/routing/worker-script/), [D1 batch API](https://developers.cloudflare.com/d1/worker-api/d1-database/), [R2 conditional operations](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/), [Access JWT validation](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/)
