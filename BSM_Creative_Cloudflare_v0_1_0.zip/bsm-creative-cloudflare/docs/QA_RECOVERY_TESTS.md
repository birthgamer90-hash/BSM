# Executed QA and recovery scope

ผลและจำนวนล่าสุดอยู่ [evidence report](../evidence/REPORT_TH.md) ไม่อ้างว่าทดสอบครบ35กรณีของdesignauditเดิม ทุกcaseต่อไปนี้เป็นimplementation-specificsuiteใหม่ ไม่มีAI/ตัวละครจริง

## รันทดสอบ

```bash
npm run init:local
npm run migrate:local
# terminal1
npm run dev
# terminal2
npm test
npm run test:browser
npm run build
node tests/restore.mjs
```

testsไม่resetDB ทุกครั้งเพิ่มfixtureIDsใหม่เฉพาะlocalnamespaceนี้ ใช้PNG/APNGmoving-square/textfixtures; HumanQA/rightscheckเป็นsimulationของauthenticatedlocalowner ไม่ใช่actualusercreativeapproval

- Unit: PNG signature/CRC/decode; APNGframe/loop/timing/motion/roles; LINEdimensions/transparency/caps; typedintake; exactThaiUTF8; JWTsignature/owner/audience/expiry
- Integration: privatefiles/CSRF; R2write/readback; idempotency; immutableMaster; state/attempt/fence/gates; all6modules; Socialcompanionoutputs; actualLINEpayloadZIPs; revision-pinnedpublishing; UnknownRemote resume withoutredispatch; D1concurrentclaims; conflicting-idempotentupload race; cancellation; journalchain/backuphashes
- Browser: 360/430touchและ1440desktop; login/dashboard/library+6modules; no pageoverflow/noJSerrors/logout401; actualUIintake→planapproval→claim→textimport→QA→release→ZIP
- Restore: freshisolatednamespace; 11tablesและregisteredobjectsเท่ากัน; dispose/reopenWorker; login/dashboard/imagebytes/ZIPexport; production-modeactualRSA JWT routeผ่านmockAccessJWKSและrejectspoofedemail/wrongowner/DEVlogin

Fault injectionเปลี่ยนlease_untilเฉพาะtestitemIDsของnewlocalDBเพื่อจำลองหมดlease ไม่ใช่productionAPIและไม่แตะระบบเก่า Initialfailedattempt logsยังเก็บไว้ แยกfinalpassingevidenceชัดเจน

## ยังไม่ทดสอบ/ยังบล็อก

RealCloudflareAccessOTP/JWKSnetwork/accountresources, FreeCPUquota, realAndroid/Windows/Safari, actualWorkimagegeneration/identity/Thai mark proof, remoteCloudrestore, Multi-workersและThemeยังNOT TESTED/BLOCKEDตามเหตุผล ห้ามเปลี่ยนเป็นPASSเพราะมีชื่อtoolหรือไฟล์sourceครบ

Go-liveต้องใช้testaccountprivateจริง ตรวจunauthorizedroot/API/assetsreject, allowedownerOTPผ่าน, CPU/memoryของboundaryimages/APNGต่อrequest, D1/R2quotas, rollback/backuprestoreและactualdevicebrowserก่อนproduction การทดสอบlocalhostไม่แทนผลเหล่านี้
