# Private R2 asset library

R2แทนDriveในระบบใหม่นี้ ไม่มีการเชื่อม/ค้น/ย้ายDriveเก่า Asset IDsและpathsสร้างใหม่เท่านั้น ไม่มีการimportข้อมูลเดิมอัตโนมัติ

## File identity and picker

Uploadจากเจ้าของ: actual PNG/JPEG bytes + original name/category/rights + optional approvedparent; serverdecode/hash→newcontent-addressedR2key→readbackhash→D1draftrecord Pickerแสดงภาพที่ผ่านauthenticatedfileendpointพร้อมname/version/category/hash ไม่ใช้filenameเป็นidentity

Keys:

```text
assets/<asset-id>/<content-sha256>
works/<work-id>/r<revision>/<item-id>/<attempt-id>/<command-object-id>/<content-sha256>
```

Parentderivativeอ้างparentID/hash/revision; WARDROBEต้องมีapprovedparent ไม่มีการเขียนbytesเดิม approvedMaster ไม่มีdelete/updateendpoint R2 conditionalput+contenthashkeys+D1recordimmutabilityเป็นapplicationcontrol ไม่ใช่storageWORM ผู้ดูแลR2ภายนอกยังแก้ได้; hash mismatchทุกread/pin/exportจึงต้องreject

Register fields: id/name/object_key/sha256/size/media/category/rights/parent_id/asset_revision/status/metadata/created_at/approved_at Approvalsผูกid/revision/hash/owner/state ไม่รับworkerapprovalเพราะระบบยังไม่ออกworkercredentials

R2bucketต้องprivate ปิดr2.dev/publicdomain/anonymousCORS Browserไม่มีR2 APIkeysหรือpresignedcredentialsใช้fetchผ่านWorkerหลังJWTauthทุกครั้ง Workไม่ได้รับaccesssecret การส่งภาพให้Workคือownerdownload→attachพร้อมsha256/lineage; ลิงก์privateเพียงอย่างเดียวไม่ยืนยันว่าWorkอ่านbytesได้

## Persistence and backup

D1authoritativeintake/state/events/approvals; R2authoritativebinarypayload R2writeกับD1commitไม่atomic ใช้staging/readback/transactioncommit Orphansจากunknowncommit/collisionไม่ลบเอง Recoveryแสดงkeys/hashให้ownerทบทวนก่อนimportใหม่

Backup endpointใช้D1batchsnapshotของ11ตารางในtransactionอ่านเดียว และเก็บregisteredR2payloadsพร้อมmetadata/hashเป็นprivate ZIP≤20MB ไฟล์นี้มีข้อมูลส่วนตัว ห้ามแจกสาธารณะ **ไม่รวมorphanstagingหรือtemporaryfilesในWorkภายนอก** สั่งreconcileและตรวจunfinishedattemptsก่อนสำรอง

Restore drillเปิดnewlocalD1/R2namespaceพร้อมmigrationใหม่ ใส่records+payloadsแล้วverifytable/hash equality เปิดfreshWorkerinstanceอ่านงาน/ล็อกอิน/exportได้ ไม่overwrite namespaceต้นทาง RemoteCloudflarebackup/restoreยังNOT TESTED ต้องทำtargetใหม่และยืนยันaccount/bindingก่อนทุกwrite ห้ามrestoreทับDB/R2ที่มีข้อมูล
