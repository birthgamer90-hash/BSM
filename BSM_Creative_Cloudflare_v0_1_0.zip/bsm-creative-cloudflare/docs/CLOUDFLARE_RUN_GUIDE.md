# Cloudflare run guide — ยังไม่ได้ deploy

ชุดนี้ไม่มีCloudflareaccountID/APItokenหรือresourcesจริง configใช้placeholderเพื่อlocaltest งานปัจจุบันอนุญาตการเขียนโค้ดและทดสอบlocalเท่านั้น ไม่ได้อนุมัติdeployหรือซื้อบริการ ขั้นตอนremoteด้านล่างเป็นคู่มือภายหลัง ไม่ได้รันในCodex

## Free-plan readiness ที่ต้องตรวจ

[Workers limits](https://developers.cloudflare.com/workers/platform/limits/) จำกัดFree CPUต่อrequest (หน้าทางการระบุ10msในการตรวจรอบนี้) FullPNG/APNGdecodeอาจเกิน โดยเฉพาะหลายframes/ภาพใหญ่ **localPASSไม่ยืนยันFreeCPUพร้อมใช้** ต้องวัดactualCPUในCloudflareaccountที่privateก่อนgo-live หากError1102ให้หยุดและออกแบบการแบ่งvalidationตามความสามารถจริง ห้ามอัปเกรดPaidโดยอัตโนมัติ

[R2 pricing](https://developers.cloudflare.com/r2/pricing/) มีFree allowanceสำหรับStandard storageและoperations แต่ส่วนเกินคิดเงิน ไม่ใช้InfrequentAccessเพื่ออ้างFree แอปcapcommittedfiles100MB/maxupload2MB/package20MBช่วยจำกัดขนาด ไม่ใช่accountbillinghardcap และไม่รวมorphanstaging อย่าอ้างใช้ฟรีไม่จำกัด ตรวจbillingactivation/usage/alertsตามบัญชีจริงก่อนเปิด

## เตรียมบัญชีและทรัพยากรใหม่ หลังอนุมัติ remote setup

ใช้Node24/ล็อกอินCloudflareผ่านnativeOAuthบนเครื่องผู้ใช้ ไม่ส่งcredentialsในchat และไม่วางAPIKeyในpublicfrontend

```bash
npx wrangler login
npx wrangler d1 create bsm-creative-db
npx wrangler r2 bucket create bsm-creative-private
```

คำสั่งเหล่านี้สร้าง**resourcesใหม่** ห้ามreuseDB/bucketงานอื่นหากยังไม่ได้รับอนุมัติ ใส่actualdatabaseIDที่คืนจริงในwrangler.jsonc R2bucketprivateต้องปิดpublicaccess/r2.dev/CORSanonymous แล้วใช้Workersbinding server-sideโดยไม่สร้างR2S3keyให้browser

เลือกWorkersFreeและR2Standardเฉพาะเมื่อเข้าใจเงื่อนไข หากระบบขอข้อมูลชำระเงินให้ผู้ใช้ดำเนินการเองผ่านCloudflare ไม่อนุมัติPaidAI/plan/creditsจากการมีtokenหรือการสร้างbucket

## กำหนด Access ก่อนให้ลิงก์ผู้ใช้

Production vars: APP_ENV=production, OWNER_EMAIL=<ownerที่กำหนดใหม่>, ACCESS_TEAM_DOMAIN=<team>.cloudflareaccess.com, ACCESS_AUD=<applicationaudience> ค่าเหล่านี้ไม่ใช่secretAPIkey แต่ต้องตรงแอปจริง

ตั้งCloudflareAccess allowpolicyเฉพาะowneremail + one-timePIN และไม่มีbypasspolicy ตั้งให้ครอบคลุมทุกpathของworkerhost รวมAPI/files/staticassets ไม่ใช้headeremailปลอมเป็นauth

ดู [workers.dev Access](https://developers.cloudflare.com/workers/configuration/routing/workers-dev/) หากบัญชีมีdashboardoptionสำหรับEnableCloudflareAccessกับworkers.dev สามารถใช้hostnameที่Cloudflareคืนจริงโดยไม่ซื้อโดเมน อย่าสร้างURLจากชื่อที่เดา หากบัญชี/routeนี้ไม่รองรับใช้customhostnameที่มีAccessapplicationถูกต้องก่อน

Sourcedefault `workers_dev=false`, `preview_urls=false` ให้คงปิดจนพร้อมตั้งAccess hostname Envowner/aud/teamที่ขาดทำให้Workerrejectทั้งหมด ไม่มีpublicfallback/DEVloginบนproduction แม้configDEVsecretหลงเข้าไปก็ไม่เปิดdevmodeบนHTTPS/publichostname

## Apply/deploy เฉพาะหลังอนุมัติ concrete release

ก่อนremotechangeเก็บprivatebackupทรัพยากรปลายทางถ้ามีข้อมูล; ห้ามreset/overwrite resourcesเดิม ขั้นตอนสำหรับ**ฐานข้อมูลใหม่ที่ว่างและยืนยันIDแล้ว**:

```bash
npx wrangler d1 migrations apply bsm-creative-db --remote
# ตรวจplan/config/accessและอนุมัติreleaseก่อน
npx wrangler deploy
```

เลือกroute/enableworkers.devตามAccessที่รองรับในaccountจริง ตัด.dev.varsออกจากbundleและห้ามcopylocalfixturestateไปproduction ต้องverifydeploymentURLที่Cloudflareคืนจริง แล้วทดสอบanonymous/owner/wrong-owner OTP, JWTcookie, privateimage/download, actualFreeCPU, allmoduleformsและChromeAndroid/Windows/Safariตามอุปกรณ์จริง

ถ้าติดauth/network/quotaให้ลงBLOCKED/NOT TESTED ไม่ปิดauthเปิดpublicbucketหรือปรับbindingDevelopmentเพื่อให้ผ่าน หน้าเว็บต้องfailclosedแม้Accessgatewayconfiguredผิด

## Backup and restore

OwnerกดprivatebackupZIP≤20MBจากLibraryเพื่อเก็บregisteredfiles+transactionalD1snapshot สำรวจunfinishedattempts/orphansก่อนสำรอง ไม่แชร์ZIPนี้สาธารณะ ข้อมูลใหญ่ใช้Cloudflareadminexportsที่ได้รับอนุมัติและตรวจhashครบ ไม่เปลี่ยนappcapโดยไม่ตรวจmemory/CPU

`tests/restore.mjs` พิสูจน์localrestoreในnewisolatednamespace/freshWorkerแล้ว ยังไม่ใช่remoteCloudflarerestoreinstaller การrestoreremoteต้องใช้newDB/bucketและverifytable/payload/approvalhashก่อนสลับbindings ห้ามนำคำสั่งtestfaultinjectionไปรันproduction

## URL status

Localhost8787ใช้ได้บนexecutionhostที่กำลังรันdevserver ไม่ใช่URLที่เปิดจากAndroidของผู้ใช้ได้ เมื่อจบQA Codexหยุดdevserverที่ตัวเองเปิดเพื่อไม่ทิ้งlistenerไว้ CloudflareprivateURLยังไม่มีในงานนี้ — NOT DEPLOYED ไม่เกี่ยวข้องกับQuickTunnelระบบเก่าที่เคยถูกบล็อก
