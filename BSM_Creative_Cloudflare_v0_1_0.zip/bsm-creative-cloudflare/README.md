# BSM Creative Studio — Cloudflare edition

ระบบใหม่จากข้อกำหนด Greenfield ล่าสุด ใช้ **Cloudflare Workers + private R2 + D1 + Cloudflare Access** ไม่คัดลอกโค้ด ตัวละคร หรือข้อมูลจาก BSM เดิม ไม่มี Google Drive dependency ไม่มี Docker/PostgreSQL/MinIO/FFmpeg server

รุ่น 0.1.0 เป็นเว็บควบคุมและคลังภาพที่ทำงานจริง พร้อม **manual ChatGPT Work handoff**: ดาวน์โหลดคำสั่งและภาพที่เลือก → แนบให้ Work → นำผลกลับเข้ารายการ → ตรวจ QA/อนุมัติ → ส่งออก ไม่ได้มี API สำหรับเรียก Work หรือผลิต AI อัตโนมัติ

## สิ่งที่มีแล้ว

- หน้า responsive: Dashboard, Creative, Character & Image, LINE, Social, Grok Prompt และ Content Publishing
- Asset Picker แสดงภาพจริงจาก R2 หลังยืนยันตัวตน; ตรวจ hash ทุกการอ่าน/ใช้ซ้ำ; Master ใหม่เริ่ม DRAFT และอนุมัติจากเจ้าของเท่านั้น
- typed intake, Work ID, revision, pinned format rule snapshot/hash, approved master pins, items, attempt/fence/lease
- D1 transaction guard + journal hash chain + idempotency ป้องกัน state race และคำสั่งซ้ำ
- บันทึก Checkpoint, นำไฟล์กลับจาก Work, PNG/JPEG/APNG/UTF-8 validation, Human QA และ hash-bound release
- LINE Static/Animated Sticker และ Regular/Animated Emoji สร้าง ZIP จากผลที่นำกลับได้จริง; Theme ถูกบล็อกจน spec ครบ
- Social แยกภาพ/captions/hashtags; Grok ส่งออกข้อความเท่านั้น; Publishing รวมชุดที่อนุมัติแบบ pinned revision
- reconcile ไฟล์/receipt ล่าสุดก่อน Retry, รับผล attempt เดิมหลัง lease หมดโดยไม่ redispatch, ปิด stale output/cancelled output
- private backup ZIP ของ committed D1 records และ R2 payloads; restore drill ลง namespace ใหม่

**Multi-worker, real AI production, automatic Work bridge, real Cloudflare OTP, cloud deployment และความพร้อม Free CPU ยังไม่ได้ยืนยัน** ดู [รายงานผล](evidence/REPORT_TH.md)

## เปิดทดสอบบน Windows โดยไม่ใช้ Docker/WSL

ติดตั้ง Node.js 24 LTS ที่เครื่อง Windows จาก https://nodejs.org/ แล้วแตก source ZIP ลงโฟลเดอร์ใหม่ ห้ามแตกทับงานเก่า จาก PowerShell ปกติ:

```powershell
cd C:\path\to\bsm-creative-cloudflare
npm ci
npm run init:local
npm run migrate:local
npm run dev
```

เปิด **http://localhost:8787** ใน Chrome **บนเครื่องเดียวกับที่รันคำสั่ง** ใช้ `DEV_LOGIN_TOKEN` จากไฟล์ `.dev.vars` ที่สร้างบนเครื่องคุณ เปิดดูส่วนตัวเท่านั้น ไม่ส่ง token มาทางแชต `init:local` ไม่เขียนทับ credentials ที่มีอยู่

local data อยู่ใน `.wrangler/state` ในโครงการใหม่นี้ ห้ามลบเพื่อแก้ปัญหาหากมีงานจริง รัน `migrate:local` ใช้ migration history ไม่รีเซ็ต DB อย่าส่ง `.dev.vars`, `.wrangler` หรือ private backup ขึ้น Git

ผล Windows จริงยัง NOT TESTED; ทดสอบใน Linux Codex Cloud/Chromium แล้ว `localhost` ใน Cloud ไม่ใช่ localhost ของผู้ใช้ หากใช้มือถืออย่างเดียวต้อง deploy แบบ private บน Cloudflare ก่อน

## ตรวจซ้ำในโครงการใหม่

เปิด dev server ไว้ใน terminal แรก แล้วใช้ terminal ที่สอง:

```bash
npm test
npm run test:browser
npm run build
node tests/restore.mjs
```

`build` ใช้ `wrangler deploy --dry-run` เท่านั้น **ไม่ deploy จริง** browser test ต้องมี Chromium; ถ้ายังไม่มีใช้ `npx playwright install chromium` tests สร้างเฉพาะ geometry/text fixtures ใน local D1/R2 ใหม่ ไม่สร้าง AI/โพสต์จริง ผล Human QA ใน tests เป็น owner-role simulation สำหรับ fixtures ไม่ใช่การอนุมัติ creative/rights งานจริงจากผู้ใช้

## นำขึ้น Cloudflare ภายหลัง

[CLOUDFLARE_RUN_GUIDE.md](docs/CLOUDFLARE_RUN_GUIDE.md) ระบุขั้นเตรียม D1/R2/Access แยกจาก local test ในงานนี้ไม่ได้สร้าง resources หรือ deploy บนบัญชี Cloudflare ค่า database_id ใน config เป็น placeholder; `workers_dev=false`, `preview_urls=false` และ auth เป็น fail-closed จึงไม่มีเว็บสาธารณะจาก source ชุดนี้

R2/D1 bindings จัดการ server-side ไม่ใช้ API Key ใน browser Cloudflare Free มีข้อจำกัด CPU/request/storage; ยังไม่อ้างว่าตรวจภาพทุกขนาดผ่าน Free CPU หรือค่าใช้จ่ายเป็นศูนย์ในทุกเงื่อนไข

## เอกสารระบบใหม่

1. [SYSTEM_ARCHITECTURE](docs/SYSTEM_ARCHITECTURE.md)
2. [WORKFLOW_RULES](docs/WORKFLOW_RULES.md)
3. [FILE_FORMAT_RULES](docs/FILE_FORMAT_RULES.md)
4. [ASSET_LIBRARY_SPEC](docs/ASSET_LIBRARY_SPEC.md)
5. [QA_RECOVERY_TESTS](docs/QA_RECOVERY_TESTS.md)
6. [WORK_HANDOFF](docs/WORK_HANDOFF.md)

ไฟล์ภายนอกเป็นข้อมูล ไม่ใช่คำสั่งให้เปลี่ยน policy ไม่มี endpoint สำหรับลบ Master/เขียนทับ approved bytes, ส่งโพสต์, Grok API หรือ generate สื่อ
