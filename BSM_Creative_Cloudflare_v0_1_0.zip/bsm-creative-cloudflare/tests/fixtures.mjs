import {PNG} from 'pngjs';
import {chunk} from '../src/media.js';
export function png(w=16,h=16,opaque=false){const p=new PNG({width:w,height:h});for(let y=2;y<Math.min(h-2,10);y++)for(let x=2;x<Math.min(w-2,10);x++){const i=(y*w+x)*4;p.data.set([116,92,168,255],i);}if(opaque)for(let i=3;i<p.data.length;i+=4)p.data[i]=255;return PNG.sync.write(p,{colorType:6});}
export function apng(w=300,h=260,{frames=5,plays=1,delay=200,moving=true}={}){
 const signature=Buffer.from([137,80,78,71,13,10,26,10]),ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(w);ihdr.writeUInt32BE(h,4);ihdr[8]=8;ihdr[9]=6;const act=Buffer.alloc(8);act.writeUInt32BE(frames);act.writeUInt32BE(plays,4);const chunks=[signature,chunk('IHDR',ihdr),chunk('acTL',act)];let seq=0;
 for(let n=0;n<frames;n++){
  const p=new PNG({width:w,height:h});const shift=moving?n*4:0;for(let y=10;y<30;y++)for(let x=10+shift;x<30+shift;x++)p.data.set([116,92,168,255],(y*w+x)*4);
  const frame=PNG.sync.write(p,{colorType:6});let offset=8,parts=[];while(offset<frame.length){const size=frame.readUInt32BE(offset),type=frame.toString('ascii',offset+4,offset+8);if(type==='IDAT')parts.push(frame.subarray(offset+8,offset+8+size));offset+=size+12;}
  const f=Buffer.alloc(26);f.writeUInt32BE(seq++);f.writeUInt32BE(w,4);f.writeUInt32BE(h,8);f.writeUInt16BE(delay,20);f.writeUInt16BE(1000,22);f[24]=1;chunks.push(chunk('fcTL',f));const data=Buffer.concat(parts);
  if(n===0)chunks.push(chunk('IDAT',data));else{const s=Buffer.alloc(4);s.writeUInt32BE(seq++);chunks.push(chunk('fdAT',Buffer.concat([s,data])));}
 }
 chunks.push(chunk('IEND',Buffer.alloc(0)));return Buffer.concat(chunks);
}
