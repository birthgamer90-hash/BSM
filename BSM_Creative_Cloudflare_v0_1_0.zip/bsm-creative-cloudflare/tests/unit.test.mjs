import test from 'node:test';
import assert from 'node:assert/strict';
import {generateKeyPair,exportJWK,SignJWT,createLocalJWKSet} from 'jose';
import {inspectImage,inspectOutput,normalizeIntake,makeItems,sha256,canonical,chunk} from '../src/media.js';
import {verifyAccess,authenticate,isLocal} from '../src/auth.js';
import {png,apng} from './fixtures.mjs';
test('Actual PNG bytes, CRC, extension, decoder and alpha validation',async()=>{
 const p=png();const m=await inspectImage(p,'fixture.png');assert.equal(m.format,'PNG_STATIC');assert.equal(m.transparent,true);assert.equal(m.width,16);
 await assert.rejects(inspectImage(p,'fixture.jpg'),/MAGIC_MISMATCH/);const broken=Buffer.from(p);broken[broken.length-6]^=1;await assert.rejects(inspectImage(broken,'x.png'),/PNG_CRC/);
 await assert.rejects(inspectImage(p.subarray(0,p.length-5),'x.png'),/PNG_TRUNCATED/);await assert.rejects(inspectImage(Buffer.from('<svg/>'),'x.svg'),/UNSUPPORTED_IMAGE/);
});
test('APNG decoding/composition, frame count, motion, rational timing and roles',async()=>{
 const data={module:'line',product_type:'animated_sticker'};const p=apng();const m=await inspectOutput(p,'01.png',data,'primary');assert.equal(m.frames,5);assert.equal(m.plays,1);assert.equal(m.cycle_ms,1000);assert.equal(m.motion,true);
 await assert.rejects(inspectOutput(png(300,260),'01.png',data,'primary'),/APNG_REQUIRED/);
 await assert.rejects(inspectOutput(apng(300,260,{frames:4,delay:250}),'01.png',data,'primary'),/FRAME_COUNT/);
 await assert.rejects(inspectOutput(apng(300,260,{plays:0}),'01.png',data,'primary'),/LOOP_COUNT/);
 await assert.rejects(inspectOutput(apng(300,260,{delay:300}),'01.png',data,'primary'),/PLAYBACK_TIME/);
 await assert.rejects(inspectOutput(apng(300,260,{delay:600,plays:2}),'01.png',data,'primary'),/PLAYBACK_TIME/);
 await assert.rejects(inspectOutput(apng(300,260,{moving:false}),'01.png',data,'primary'),/NO_MOTION/);
 await assert.rejects(inspectOutput(apng(200,200),'01.png',data,'primary'),/DIMENSION/);
 assert.equal((await inspectOutput(apng(240,240),'main.png',data,'main')).format,'APNG');
 assert.equal((await inspectOutput(png(96,74),'tab.png',data,'tab')).format,'PNG_STATIC');
 await assert.rejects(inspectOutput(apng(96,74),'tab.png',data,'tab'),/STATIC_REQUIRED/);
});
test('LINE separate static/emoji dimensions and opaque rejection',async()=>{
 await assert.rejects(inspectOutput(png(371,320),'01.png',{module:'line',product_type:'static_sticker'},'primary'),/DIMENSION/);
 await assert.rejects(inspectOutput(png(370,320,true),'01.png',{module:'line',product_type:'static_sticker'},'primary'),/ALPHA_POLICY/);
 assert.equal((await inspectOutput(png(180,180),'001.png',{module:'line',product_type:'regular_emoji'},'primary')).technical,'PASS');
 await assert.rejects(inspectOutput(png(180,182),'001.png',{module:'line',product_type:'regular_emoji'},'primary'),/DIMENSION/);
 assert.equal((await inspectOutput(apng(180,180),'001.png',{module:'line',product_type:'animated_emoji'},'primary')).technical,'PASS');
 await assert.rejects(inspectOutput(png(180,180),'001.png',{module:'line',product_type:'theme'},'primary'),/THEME_SPEC_UNVERIFIED/);
 const tab=png(96,74),padded=Buffer.concat([tab.subarray(0,-12),chunk('tEXt',Buffer.alloc(300_000,65)),tab.subarray(-12)]);
 await assert.rejects(inspectOutput(padded,'tab.png',{module:'line',product_type:'animated_emoji'},'tab'),/FILE_SIZE/);
});
test('Typed intake, count, mode, Grok video restrictions and companion roles',()=>{
 const base={module:'line',product_type:'static_sticker',title:'Sandbox',brief:'geometry test only',audience:'test',language:'ไทย',count:8,asset_ids:['fixture']};
 assert.equal(makeItems(normalizeIntake(base)).length,10);assert.throws(()=>normalizeIntake({...base,count:7}),/PACK_COUNT/);assert.throws(()=>normalizeIntake({...base,mode:'Multi-worker'}),/MULTI_WORKER/);
 assert.throws(()=>normalizeIntake({...base,module:'grok',product_type:'video'}),/TYPE_MISSING/);assert.throws(()=>normalizeIntake({...base,paid_api:true}),/EXPORT_ONLY/);
 assert.equal(makeItems(normalizeIntake({...base,module:'social',product_type:'social_image',count:1})).length,3);
 assert.throws(()=>normalizeIntake({...base,module:'publishing',product_type:'content_package',count:1}),/APPROVED_RELEASE_REQUIRED/);
});
test('Exact Thai UTF8 text and canonical stable hash',async()=>{
 const text='งื้อ ห๊ะ จึ้งมาก อะฮิ อะฮิ';const d={product_type:'prompt_text',exact_text:text};assert.equal((await inspectOutput(new TextEncoder().encode(text),'001.md',d,'primary')).technical,'PASS');
 await assert.rejects(inspectOutput(new TextEncoder().encode('wrong'),'001.md',d,'primary'),/TEXT_MISMATCH/);await assert.rejects(inspectOutput(new Uint8Array([255]),'001.md',d,'primary'),/TEXT_UTF8/);
 assert.equal(await sha256(canonical({z:1,a:2})),await sha256(canonical({a:2,z:1})));
});
test('Production Access JWT signature, issuer, audience, owner and expiry checks',async()=>{
 const {publicKey,privateKey}=await generateKeyPair('RS256');const jwk=await exportJWK(publicKey);jwk.kid='sandbox';const jwks=createLocalJWKSet({keys:[jwk]});
 const cfg={ACCESS_TEAM_DOMAIN:'sandbox.cloudflareaccess.com',ACCESS_AUD:'owner-aud',OWNER_EMAIL:'owner@example.test'};
 const sign=(overrides={})=>new SignJWT({email:cfg.OWNER_EMAIL,...overrides}).setProtectedHeader({alg:'RS256',kid:'sandbox'}).setIssuer('https://'+cfg.ACCESS_TEAM_DOMAIN).setAudience(cfg.ACCESS_AUD).setIssuedAt().setExpirationTime('2m').sign(privateKey);
 assert.equal((await verifyAccess(await sign(),cfg,jwks)).kind,'cloudflare-access');
 await assert.rejects(verifyAccess(await sign({email:'intruder@example.test'}),cfg,jwks),/Wrong owner/);
 await assert.rejects(verifyAccess(await sign(),{...cfg,ACCESS_AUD:'wrong-aud'},jwks));
 const expired=await new SignJWT({email:cfg.OWNER_EMAIL}).setProtectedHeader({alg:'RS256',kid:'sandbox'}).setIssuer('https://'+cfg.ACCESS_TEAM_DOMAIN).setAudience(cfg.ACCESS_AUD).setExpirationTime(1).sign(privateKey);await assert.rejects(verifyAccess(expired,cfg,jwks));
 const req=new Request('https://public.example/api/assets',{headers:{'Cf-Access-Authenticated-User-Email':cfg.OWNER_EMAIL}});assert.equal(await authenticate(req,cfg),null);
 assert.equal(isLocal(req,{APP_ENV:'development'}),false);assert.equal(await authenticate(req,{APP_ENV:'development',DEV_LOGIN_TOKEN:'anything'}),null);
});
