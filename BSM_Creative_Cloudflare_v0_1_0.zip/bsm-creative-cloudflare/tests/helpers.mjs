import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
export const BASE=process.env.BCS_TEST_URL||'http://127.0.0.1:8787';
export let cookie='';
export const uid=()=>crypto.randomUUID();
export async function login(){const vars=readFileSync(new URL('../.dev.vars',import.meta.url),'utf8');const token=vars.match(/^DEV_LOGIN_TOKEN="([^"]+)"/m)[1];const res=await fetch(BASE+'/auth/local-login',{method:'POST',headers:{Origin:BASE,'X-BCS-Intent':'write','Content-Type':'application/json'},body:JSON.stringify({token})});assert.equal(res.status,200);cookie=res.headers.get('set-cookie').split(';')[0];return cookie;}
export async function call(path,method='GET',data,options={}){
 const headers={...(options.noauth?{}:{Cookie:cookie}),...(method==='GET'?{}:{Origin:BASE,'X-BCS-Intent':'write','Idempotency-Key':options.key||uid()})};
 if(options.metadata)headers['X-BCS-Metadata']=encodeURIComponent(JSON.stringify(options.metadata));else if(data!==undefined)headers['Content-Type']='application/json';
 const res=await fetch(BASE+path,{method,headers:{...headers,...options.headers},body:options.raw|| (data===undefined?undefined:JSON.stringify(data))});
 if(options.binary)return {res,bytes:new Uint8Array(await res.arrayBuffer())};const body=await res.json();return {res,body};
}
export async function ok(path,method='GET',data,options={}){const r=await call(path,method,data,options);assert.equal(r.res.status,200,JSON.stringify({path,body:r.body}));return r.body;}
export const intake=(module,type,count=1,extra={})=>({module,product_type:type,count,title:'SANDBOX '+uid().slice(0,8),brief:'Geometric/text fixture only; no real media, no AI calls.',audience:'sandbox',language:'ไทย',mode:'Single',width:16,height:16,...extra});
export async function plan(data){const w=await ok('/api/works','POST',data);await ok(`/api/works/${w.id}/approve-plan`,'POST',{revision:w.revision,plan_reviewed:true});return w;}
export async function output(w,item,bytes,name){const claim=await ok(`/api/works/${w.id}/items/${item}/claim`,'POST',{revision:w.revision,worker:'sandbox-fixture-worker'});const a=await ok(`/api/works/${w.id}/items/${item}/output`,'POST',undefined,{raw:bytes,metadata:{revision:w.revision,attempt_id:claim.attempt_id,fence:claim.fence,filename:name}});await ok(`/api/artifacts/${a.artifact_id}/review`,'POST',{sha256:a.sha256,creative_reviewed:true,rights_reviewed:true,text_reviewed:true,continuity_reviewed:true});return a;}
export async function release(w){const m=await ok(`/api/works/${w.id}/manifest`);await ok(`/api/works/${w.id}/release`,'POST',{revision:w.revision,manifest_sha256:m.manifest_sha256,release_reviewed:true});return m;}
