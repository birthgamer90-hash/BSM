import test,{before} from 'node:test';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {unzipSync,strFromU8} from 'fflate';
import {canonical,sha256} from '../src/media.js';
import {png,apng} from './fixtures.mjs';
import {BASE,login,call,ok,uid,intake,plan,output,release,cookie} from './helpers.mjs';
let master,released,releaseManifest;const records={scope:'NEW_LOCAL_D1_R2_SANDBOX_ONLY',paid_ai_calls:0,real_media_created:0,fixtures:[],work_ids:[]};
before(login);
test('Unauthenticated private API/files, CSRF, cookie and local-only access',async()=>{
 assert.equal((await call('/api/assets','GET',undefined,{noauth:true})).res.status,401);
 assert.equal((await call('/api/dashboard','GET',undefined,{noauth:true})).res.status,401);
 assert.equal((await call('/api/assets/unknown/file','GET',undefined,{noauth:true})).res.status,401);
 assert.equal((await call('/api/works','POST',{}, {headers:{Origin:'https://attacker.example'}})).res.status,403);
 assert.equal((await call('/api/works','POST',{}, {headers:{'X-BCS-Intent':''}})).res.status,403);
 const html=await fetch(BASE);assert.match(html.headers.get('content-security-policy'),/frame-ancestors 'none'/);
 assert.equal(html.headers.get('cache-control'),'private, no-store');assert.equal((await ok('/api/me')).auth,'local-test');
});
test('Actual R2 upload/readback, idempotency, Master approval and immutable endpoints',async()=>{
 const bytes=png(),key=uid(),metadata={name:'sandbox-geometry.png',category:'TEST_FIXTURE',rights:{owner:'sandbox',license:'test fixture only'}};
 master=await ok('/api/assets','POST',undefined,{raw:bytes,metadata,key});assert.equal(master.status,'DRAFT');assert.equal(master.sha256,await sha256(bytes));
 const again=await ok('/api/assets','POST',undefined,{raw:bytes,metadata,key});assert.equal(again.id,master.id);
 assert.equal((await call('/api/assets','POST',undefined,{raw:png(18,18),metadata,key})).res.status,409);
 assert.equal((await call(`/api/assets/${master.id}/approve`,'POST',{sha256:'wrong',creative_reviewed:true,rights_reviewed:true})).res.status,409);
 await ok(`/api/assets/${master.id}/approve`,'POST',{sha256:master.sha256,creative_reviewed:true,rights_reviewed:true});
 assert.equal((await call(`/api/assets/${master.id}/approve`,'POST',{sha256:master.sha256,creative_reviewed:true,rights_reviewed:true})).res.status,409);
 const r=await call(`/api/assets/${master.id}/file`,'GET',undefined,{binary:true});assert.equal(await sha256(r.bytes),master.sha256);assert.equal(r.res.headers.get('content-type'),'image/png');
 assert.equal((await call(`/api/assets/${master.id}`,'PATCH',{name:'overwrite'})).res.status,404);
 records.fixtures.push({asset_id:master.id,sha256:master.sha256});
});
test('Intake gates, exact names, stale fence, Human QA and hash-bound release',async()=>{
 assert.equal((await call('/api/works','POST',intake('line','static_sticker',7,{asset_ids:[master.id]}))).res.status,422);
 assert.equal((await call('/api/works','POST',intake('grok','video'))).res.status,422);
 assert.equal((await call('/api/works','POST',intake('creative','series_script',1,{mode:'Multi-worker'}))).res.status,422);
 const w=await ok('/api/works','POST',intake('creative','series_script',2));records.work_ids.push(w.id);
 assert.equal((await call(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1})).res.status,409);
 await ok(`/api/works/${w.id}/approve-plan`,'POST',{revision:1,plan_reviewed:true});
 const claim=await ok(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1});
 assert.equal((await call(`/api/works/${w.id}/items/002/claim`,'POST',{revision:1})).res.status,409);
 await ok(`/api/works/${w.id}/items/001/checkpoint`,'POST',{revision:1,...claim,kind:'CP_DISPATCH',evidence:'SIMULATED local text fixture; no remote execution'});
 const raw=new TextEncoder().encode('# Sandbox text fixture\nไม่มีงานสื่อจริง');
 assert.equal((await call(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw,metadata:{revision:1,...claim,fence:claim.fence+1,filename:'001.md'}})).res.status,409);
 assert.equal((await call(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw,metadata:{revision:1,...claim,filename:'wrong.md'}})).res.status,422);
 const a=await ok(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw,metadata:{revision:1,...claim,filename:'001.md'}});
 assert.equal((await call(`/api/artifacts/${a.artifact_id}/review`,'POST',{sha256:a.sha256})).res.status,409);
 await ok(`/api/artifacts/${a.artifact_id}/review`,'POST',{sha256:a.sha256,creative_reviewed:true,rights_reviewed:true,text_reviewed:true,continuity_reviewed:true});
 await output(w,'002',raw,'002.md');const m=await ok(`/api/works/${w.id}/manifest`);
 assert.equal((await call(`/api/works/${w.id}/release`,'POST',{revision:1,manifest_sha256:'wrong',release_reviewed:true})).res.status,409);
 assert.equal((await call(`/api/works/${w.id}/export`)).res.status,409);
 releaseManifest=await release(w);released=w;const exportRes=await call(`/api/works/${w.id}/export`,'GET',undefined,{binary:true});assert.equal(exportRes.res.status,200);const zip=unzipSync(exportRes.bytes);assert.deepEqual(Object.keys(zip).sort(),['001.md','002.md']);assert.equal(await sha256(zip['001.md']),a.sha256);
 assert.equal((await call(`/api/works/${w.id}/publish`,'POST',{})).res.status,403);assert.equal((await call(`/api/works/${w.id}/generate`,'POST',{})).res.status,403);
});
test('Character, Social and Grok modules: actual files and companion outputs',async()=>{
 for(const [module,type] of [['character','master_image'],['character','wardrobe_image'],['social','social_image'],['grok','storyboard'],['grok','prompt_text']]){
  const w=await plan(intake(module,type,1,{asset_ids:module==='character'||module==='social'?[master.id]:[]}));records.work_ids.push(w.id);const detail=await ok(`/api/works/${w.id}`);
  for(const item of detail.items){const text=item.filename.endsWith('.md');await output(w,item.item_id,text?new TextEncoder().encode('# Sandbox only\nCaption / prompt / hashtag fixture'):png(),item.filename);}
  await release(w);assert.equal((await ok(`/api/works/${w.id}`)).state,'EXPORT_READY');
  const handoff=await fetch(BASE+`/api/works/${w.id}/handoff`,{headers:{Cookie:cookie}});assert.equal(handoff.status,200);assert.match(await handoff.text(),/manual handoff/);
 }
});
test('LINE static/animated Sticker and Emoji packages validate actual geometry bytes',async()=>{
 for(const type of ['static_sticker','animated_sticker','regular_emoji','animated_emoji']){
  const w=await plan(intake('line',type,8,{asset_ids:[master.id]}));records.work_ids.push(w.id);const detail=await ok(`/api/works/${w.id}`);assert.equal(detail.items.length,type.includes('sticker')?10:9);
  for(const item of detail.items){let raw;if(item.role==='tab')raw=png(96,74);else if(item.role==='main')raw=type==='animated_sticker'?apng(240,240):png(240,240);else if(type==='animated_sticker')raw=apng();else if(type==='animated_emoji')raw=apng(180,180);else if(type==='regular_emoji')raw=png(180,180);else raw=png(370,320);await output(w,item.item_id,raw,item.filename);}
  const m=await release(w);const r=await call(`/api/works/${w.id}/export`,'GET',undefined,{binary:true});assert.equal(r.res.status,200);const payload=unzipSync(r.bytes);assert.equal(Object.keys(payload).length,detail.items.length);for(const f of m.files)assert.equal(await sha256(payload[f.name]),f.sha256);
 }
 const theme=await ok('/api/works','POST',intake('line','theme',1,{asset_ids:[master.id]}));assert.equal((await call(`/api/works/${theme.id}/approve-plan`,'POST',{revision:1,plan_reviewed:true})).body.error,'THEME_SPEC_UNVERIFIED');
});
test('Publishing combines hash-pinned approved media; source revision preserves prior release',async()=>{
 const w=await plan(intake('publishing','content_package',1,{source_work_ids:[released.id]}));records.work_ids.push(w.id);await output(w,'001',new TextEncoder().encode('# Sandbox delivery checklist'),'001.md');const m=await release(w);assert.equal(m.files.length,3);
 const r=await call(`/api/works/${w.id}/export`,'GET',undefined,{binary:true});assert.equal(r.res.status,200);assert.equal(Object.keys(unzipSync(r.bytes)).length,3);
 await ok(`/api/works/${released.id}/revise`,'POST',{revision:1,changes:{brief:'Revised sandbox text; previous bytes remain unchanged'}});
 assert.equal((await ok(`/api/works/${released.id}`)).state,'PLANNED');assert.equal((await call(`/api/works/${released.id}/export`)).res.status,409);
 const pinned=await call(`/api/works/${w.id}/export`,'GET',undefined,{binary:true});assert.equal(pinned.res.status,200);assert.equal(Object.keys(unzipSync(pinned.bytes)).length,3);
});
test('Unknown remote recovery resumes same attempt without redispatch, preserves fence/checkpoints',async()=>{
 const w=await plan(intake('creative','series_script'));records.work_ids.push(w.id);const c=await ok(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1});await ok(`/api/works/${w.id}/items/001/unknown`,'POST',{revision:1,...c});await ok(`/api/works/${w.id}/pause`,'POST',{revision:1});
 const sql=`UPDATE items SET lease_until=0 WHERE work_id='${w.id}' AND revision=1 AND item_id='001'`;
 const fault=spawnSync('node',['node_modules/wrangler/bin/wrangler.js','d1','execute','bsm-creative-db','--local','--command',sql],{cwd:new URL('..',import.meta.url),encoding:'utf8'});assert.equal(fault.status,0,'Local sandbox lease fault injection failed');
 const inspection=await ok(`/api/works/${w.id}/reconcile`,'POST',{revision:1});assert.equal(inspection.items[0].expired,true);assert.equal(inspection.automatic_retry,false);
 const retry=await call(`/api/works/${w.id}/items/001/retry`,'POST',{revision:1,reconciliation_id:inspection.id,confirm_no_remote_action:true,evidence:'sandbox fault evidence'});assert.equal(retry.body.error,'UNKNOWN_REMOTE_REQUIRES_RECEIPT_NO_BLIND_RETRY');
 const resumed=await ok(`/api/works/${w.id}/items/001/restore-lease`,'POST',{revision:1,reconciliation_id:inspection.id,confirm_resume_existing_attempt:true,evidence:'Existing attempt output obtained manually in sandbox'});assert.equal(resumed.attempt_id,c.attempt_id);assert.equal(resumed.fence,c.fence);assert.equal(resumed.redispatched,false);
 const a=await ok(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw:new TextEncoder().encode('# Recovered same attempt fixture'),metadata:{revision:1,...c,filename:'001.md'}});await ok(`/api/artifacts/${a.artifact_id}/review`,'POST',{sha256:a.sha256,creative_reviewed:true,rights_reviewed:true,text_reviewed:true,continuity_reviewed:true});await release(w);
 assert.equal((await ok(`/api/works/${w.id}`)).items[0].attempt_id,c.attempt_id);
});
test('Concurrent claims serialize through D1 guard; known-safe Retry needs fresh reconciliation',async()=>{
 const w=await plan(intake('creative','series_script'));records.work_ids.push(w.id);const candidates=await Promise.all(Array.from({length:6},()=>call(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1})));assert.equal(candidates.filter(x=>x.res.status===200).length,1);assert.ok(candidates.every(x=>[200,409].includes(x.res.status)));
 assert.equal((await call(`/api/works/${w.id}/items/001/retry`,'POST',{revision:1,confirm_no_remote_action:true,evidence:'sandbox test'})).body.error,'RECONCILE_BEFORE_RETRY');
 const fault=spawnSync('node',['node_modules/wrangler/bin/wrangler.js','d1','execute','bsm-creative-db','--local','--command',`UPDATE items SET lease_until=0 WHERE work_id='${w.id}' AND item_id='001'`],{cwd:new URL('..',import.meta.url),encoding:'utf8'});assert.equal(fault.status,0);
 const inspected=await ok(`/api/works/${w.id}/reconcile`,'POST',{revision:1});const r=await ok(`/api/works/${w.id}/items/001/retry`,'POST',{revision:1,reconciliation_id:inspected.id,confirm_no_remote_action:true,evidence:'Verified local fixture never dispatched any external action'});assert.equal(r.state,'READY');
 const after=await ok(`/api/works/${w.id}`);assert.equal(after.items[0].retries,1);assert.ok(after.items[0].fence>1);
});
test('Concurrent conflicting idempotency payloads cannot overwrite committed R2 output',async()=>{
 const w=await plan(intake('creative','series_script'));records.work_ids.push(w.id);const attempt=await ok(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1});const key=uid(),metadata={revision:1,...attempt,filename:'001.md'};
 const responses=await Promise.all(['# Geometry candidate A','# Geometry candidate B'].map(t=>call(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw:new TextEncoder().encode(t),metadata,key})));
 const winner=responses.find(r=>r.res.status===200);assert.ok(winner);assert.equal(responses.filter(r=>r.res.status===200).length,1);assert.equal(responses.find(r=>r!==winner).res.status,409);
 const stored=await call(`/api/artifacts/${winner.body.artifact_id}/file`,'GET',undefined,{binary:true});assert.equal(stored.res.status,200);assert.equal(await sha256(stored.bytes),winner.body.sha256);
 const inspection=await ok(`/api/works/${w.id}/reconcile`,'POST',{revision:1});assert.equal(inspection.observations[0].status,'VERIFIED');assert.equal(inspection.automatic_retry,false);
});
test('Cancelled work rejects late output and cannot release',async()=>{
 const w=await plan(intake('creative','series_script'));records.work_ids.push(w.id);const c=await ok(`/api/works/${w.id}/items/001/claim`,'POST',{revision:1});await ok(`/api/works/${w.id}/cancel`,'POST',{revision:1});
 const late=await call(`/api/works/${w.id}/items/001/output`,'POST',undefined,{raw:new TextEncoder().encode('# late'),metadata:{revision:1,...c,filename:'001.md'}});assert.equal(late.res.status,409);assert.equal((await ok(`/api/works/${w.id}`)).state,'CANCELLED');
});
test('D1 journal chain recomputation and R2 backup payloads match hashes',async()=>{
 const journal=await ok('/api/journal');let head='GENESIS',seq=0;for(const e of journal){assert.equal(e.seq,++seq);assert.equal(e.previous_hash,head);assert.equal(e.hash,await sha256(canonical({seq:e.seq,previous:e.previous_hash,type:e.type,work:e.work_id,revision:e.revision,data:JSON.parse(e.data),created_at:e.created_at})));head=e.hash;}
 const backup=await call('/api/backup','GET',undefined,{binary:true});assert.equal(backup.res.status,200);const files=unzipSync(backup.bytes);const snapshot=JSON.parse(strFromU8(files['control-snapshot.json']));assert.equal(snapshot.records.control[0].head_hash,head);
 for(const a of [...snapshot.records.assets,...snapshot.records.artifacts])assert.equal(await sha256(files['objects/'+a.id]),a.sha256);
 records.journal_events=journal.length;records.backup_files=Object.keys(files).length;writeFileSync(new URL('../evidence/integration-records.json',import.meta.url),JSON.stringify(records,null,2));
});
