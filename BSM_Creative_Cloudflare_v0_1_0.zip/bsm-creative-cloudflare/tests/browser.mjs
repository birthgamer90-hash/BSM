import {chromium} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {unzipSync,strFromU8} from 'fflate';
const base='http://127.0.0.1:8787',token=readFileSync(new URL('../.dev.vars',import.meta.url),'utf8').match(/^DEV_LOGIN_TOKEN="([^"]+)"/m)[1];
const titles={dashboard:'พื้นที่สร้างสรรค์ของคุณ',library:'คลังภาพส่วนตัว',creative:'Creative Lab',character:'Character & Image Lab',line:'LINE Studio',social:'Social Image Lab',grok:'Grok Prompt Studio',publishing:'Content Publishing Lab'};
const report={checks:[],actual_android:'NOT TESTED',actual_windows:'NOT TESTED',public_cloudflare_url:'NOT DEPLOYED',browser:'Chromium touch emulation'};
const browser=await chromium.launch({headless:true});
try{
 for(const width of [360,430,1440]){
  const context=await browser.newContext({viewport:{width,height:900},isMobile:width<720,hasTouch:width<720,acceptDownloads:true});const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.name));
  await page.goto(base);await page.locator('#login').waitFor({state:'visible'});if(width===360)await page.screenshot({path:'evidence/mobile-login.png'});
  await page.getByLabel('รหัสเข้าทดสอบภายในเครื่อง').fill(token);await page.getByRole('button',{name:'เข้าสู่ Studio'}).click();await page.getByRole('heading',{name:titles.dashboard,exact:true}).waitFor();
  const cookie=(await context.cookies()).find(c=>c.name==='bcs_session');assert.equal(cookie.httpOnly,true);assert.equal(cookie.sameSite,'Strict');
  for(const [route,title] of Object.entries(titles)){
   await page.goto(base+'/#'+route);await page.getByRole('heading',{name:title,exact:true}).waitFor();
   if(route==='library')await page.waitForFunction(()=>Array.from(document.querySelectorAll('.asset img')).every(im=>im.complete&&im.naturalWidth>0));
   const geometry=await page.evaluate(()=>({viewport:innerWidth,page_width:document.documentElement.scrollWidth}));assert.ok(geometry.page_width<=width+1,JSON.stringify({route,geometry}));
   await page.screenshot({path:`evidence/${width}-${route}.png`});report.checks.push({name:route,width,status:'PASS',...geometry});
  }
  if(width===360){
   await page.goto(base+'/#grok');await page.getByRole('heading',{name:titles.grok,exact:true}).waitFor();
   await page.locator('#product-type').selectOption('prompt_text');await page.getByLabel('ชื่อใบงาน',{exact:true}).fill('SANDBOX Mobile Work handoff');await page.getByLabel('รายละเอียดและข้อจำกัด').fill('Text-only fixture in the new Cloudflare workspace. No real generation.');await page.getByLabel('กลุ่มผู้ชม').fill('sandbox');const text='งื้อ ห๊ะ จึ้งมาก อะฮิ อะฮิ';await page.getByLabel('ข้อความที่ต้องคงตรงตามต้นฉบับ').fill(text);
   await page.getByRole('button',{name:'บันทึกแผนงาน →'}).click();await page.getByRole('heading',{name:'SANDBOX Mobile Work handoff',exact:true}).waitFor();await page.locator('#plan-check').check();await page.locator('#approve-plan').click();await page.locator('[data-claim]').waitFor();await page.locator('[data-claim]').click();const upload=page.locator('form[data-output]');await upload.waitFor();await upload.locator('input[type=file]').setInputFiles({name:'001.md',mimeType:'text/markdown',buffer:Buffer.from('# Sandbox\n'+text)});await upload.getByRole('button',{name:'นำเข้าและตรวจไฟล์',exact:true}).click();await page.locator('[data-review-check]').waitFor();await page.locator('[data-review-check]').check();await page.locator('[data-review]').click();await page.locator('#load-manifest').waitFor();await page.locator('#load-manifest').click();await page.locator('#release-check').waitFor();await page.locator('#release-check').check();await page.locator('#approve-release').click();const link=page.getByRole('link',{name:'ดาวน์โหลด ZIP ผลลัพธ์ ↓'});await link.waitFor();const event=page.waitForEvent('download');await link.click();const download=await event;assert.equal(await download.failure(),null);await download.saveAs('evidence/mobile-ui-export.zip');const zip=unzipSync(readFileSync('evidence/mobile-ui-export.zip'));assert.ok(strFromU8(zip['001.md']).includes(text));await page.screenshot({path:'evidence/mobile-release.png'});report.checks.push({name:'Mobile UI intake→plan approval→claim→actual text import→Human QA→release→ZIP download',status:'PASS',width});
  }
  await page.locator('#logout').click();await page.locator('#login').waitFor({state:'visible'});assert.equal((await page.request.get(base+'/api/dashboard')).status(),401);assert.deepEqual(errors,[]);report.checks.push({name:'Logout and protected API; no page JavaScript errors',width,status:'PASS'});await context.close();
 }
 report.status='PASS';
}catch(e){report.status='FAIL';report.error=e.message.replaceAll(token,'[REDACTED]');process.exitCode=1;}
finally{await browser.close();writeFileSync('evidence/browser-results.json',JSON.stringify(report,null,2));console.log(JSON.stringify({status:report.status,checks:report.checks.length,error:report.error}));}
