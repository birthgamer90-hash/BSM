import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {unzipSync,strFromU8} from 'fflate';
import {generateKeyPair,exportJWK,SignJWT} from 'jose';
import {login,call} from './helpers.mjs';
import {sha256,canonical} from '../src/media.js';
await login();const backup=await call('/api/backup','GET',undefined,{binary:true});assert.equal(backup.res.status,200);
const files=unzipSync(backup.bytes),snapshot=JSON.parse(strFromU8(files['control-snapshot.json']));
const vars=readFileSync('.dev.vars','utf8');const value=key=>vars.match(new RegExp('^'+key+'="([^\"]+)"','m'))[1];
const stamp=crypto.randomUUID(),folder=resolve('.wrangler','isolated-restore-'+stamp);mkdirSync(folder,{recursive:true,mode:0o700});
const options=convertV4MiniflareOptions({modules:true,scriptPath:resolve('dist/worker.js'),compatibilityDate:'2026-10-01',compatibilityFlags:['nodejs_compat'],bindings:{APP_ENV:'development',DEV_LOGIN_TOKEN:value('DEV_LOGIN_TOKEN'),DEV_SESSION_SECRET:value('DEV_SESSION_SECRET')},d1Databases:{DB:'isolated-restore-db-'+stamp},r2Buckets:{BUCKET:'isolated-restore-bucket-'+stamp},resourcePersistencePath:folder,telemetry:{enabled:false}});
const tables=['control','commands','events','assets','works','revisions','items','artifacts','checkpoints','approvals','reconciliations'];
let mf=new Miniflare(options),result={scope:'NEW_ISOLATED_LOCAL_D1_R2',original_namespace_overwritten:false,checks:[]};
try{
 const db=await mf.getD1Database('DB'),bucket=await mf.getR2Bucket('BUCKET');await db.exec(readFileSync('migrations/0001_initial.sql','utf8'));
 const statements=[];for(const table of tables){for(const row of snapshot.records[table]){const columns=Object.keys(row);assert.ok(columns.every(c=>/^[a-z_][a-z0-9_]*$/.test(c)));if(table==='control')statements.push(db.prepare('UPDATE control SET version=?,head_hash=? WHERE id=1').bind(row.version,row.head_hash));else statements.push(db.prepare(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).bind(...columns.map(c=>row[c])));}}
 await db.batch(statements);let count=0;
 for(const a of [...snapshot.records.assets,...snapshot.records.artifacts]){const bytes=files['objects/'+a.id];assert.equal(await sha256(bytes),a.sha256);await bucket.put(a.object_key,bytes,{httpMetadata:{contentType:a.media},customMetadata:{sha256:a.sha256}});count++;}
 for(const t of tables){const restored=(await db.prepare('SELECT * FROM '+t).all()).results;assert.deepEqual(restored.map(canonical).sort(),snapshot.records[t].map(canonical).sort());}
 result.checks.push({name:'All business/control tables and committed R2 payloads restored',status:'PASS',tables:tables.length,objects:count});
 await mf.dispose();mf=new Miniflare(options);
 const origin='http://127.0.0.1:8788';const response=await mf.dispatchFetch(origin+'/auth/local-login',{method:'POST',headers:{Origin:origin,'X-BCS-Intent':'write','Content-Type':'application/json'},body:JSON.stringify({token:value('DEV_LOGIN_TOKEN')})});assert.equal(response.status,200);const cookie=response.headers.get('set-cookie').split(';')[0];
 const dashboard=await mf.dispatchFetch(origin+'/api/dashboard',{headers:{Cookie:cookie}});assert.equal(dashboard.status,200);const data=await dashboard.json();assert.equal(data.counts.works,snapshot.records.works.length);
 for(const a of snapshot.records.assets){const file=await mf.dispatchFetch(origin+`/api/assets/${a.id}/file`,{headers:{Cookie:cookie}});assert.equal(file.status,200);assert.equal(await sha256(await file.arrayBuffer()),a.sha256);}
 const released=snapshot.records.works.find(w=>w.state==='EXPORT_READY');const exportRes=await mf.dispatchFetch(origin+`/api/works/${released.id}/export`,{headers:{Cookie:cookie}});assert.equal(exportRes.status,200);assert.ok(Object.keys(unzipSync(new Uint8Array(await exportRes.arrayBuffer()))).length>0);
 result.checks.push({name:'Fresh Worker instance: login, Dashboard, private image bytes and approved ZIP export',status:'PASS',works:data.counts.works});
 await mf.dispose();
 const {publicKey,privateKey}=await generateKeyPair('RS256'),jwk=await exportJWK(publicKey);jwk.kid='sandbox-runtime';
 mf=new Miniflare(convertV4MiniflareOptions({modules:true,scriptPath:resolve('dist/worker.js'),compatibilityDate:'2026-10-01',compatibilityFlags:['nodejs_compat'],resourcePersistencePath:folder,telemetry:{enabled:false},bindings:{APP_ENV:'production',DEV_LOGIN_TOKEN:value('DEV_LOGIN_TOKEN'),DEV_SESSION_SECRET:value('DEV_SESSION_SECRET'),OWNER_EMAIL:'owner@example.test',ACCESS_TEAM_DOMAIN:'sandbox.cloudflareaccess.com',ACCESS_AUD:'sandbox-audience'},d1Databases:{DB:'isolated-restore-db-'+stamp},r2Buckets:{BUCKET:'isolated-restore-bucket-'+stamp},outboundService:req=>new URL(req.url).href==='https://sandbox.cloudflareaccess.com/cdn-cgi/access/certs'?Response.json({keys:[jwk]}):new Response('No real outbound access',{status:403})}));
 assert.equal((await mf.dispatchFetch(origin+'/api/dashboard')).status,401);
 assert.equal((await mf.dispatchFetch(origin+'/auth/local-login',{method:'POST',headers:{Origin:origin,'X-BCS-Intent':'write','Content-Type':'application/json'},body:JSON.stringify({token:value('DEV_LOGIN_TOKEN')})})).status,403);
 assert.equal((await mf.dispatchFetch(origin+'/api/dashboard',{headers:{'Cf-Access-Authenticated-User-Email':'owner@example.test'}})).status,401);
 const signed=await new SignJWT({email:'owner@example.test'}).setProtectedHeader({alg:'RS256',kid:jwk.kid}).setIssuer('https://sandbox.cloudflareaccess.com').setAudience('sandbox-audience').setIssuedAt().setExpirationTime('2m').sign(privateKey);
 assert.equal((await mf.dispatchFetch(origin+'/api/dashboard',{headers:{'Cf-Access-Jwt-Assertion':signed}})).status,200);
 const stranger=await new SignJWT({email:'intruder@example.test'}).setProtectedHeader({alg:'RS256',kid:jwk.kid}).setIssuer('https://sandbox.cloudflareaccess.com').setAudience('sandbox-audience').setIssuedAt().setExpirationTime('2m').sign(privateKey);
 assert.equal((await mf.dispatchFetch(origin+'/api/dashboard',{headers:{'Cf-Access-Jwt-Assertion':stranger}})).status,401);
 result.checks.push({name:'Production Worker validates actual RSA JWT; spoofed email, wrong owner and local login blocked',status:'PASS',jwks:'SIMULATED_ACCESS_JWKS',real_cloudflare_otp:'NOT TESTED'});result.status='PASS';
}catch(e){result.status='FAIL';result.error=e.message;process.exitCode=1;}
finally{await mf.dispose();writeFileSync('evidence/restore-results.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));}
